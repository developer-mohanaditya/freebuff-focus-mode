/**
 * Freebuff Focus Mode - content script
 *
 * Network rules (rules.json) stop ad requests before they leave the browser,
 * but they cannot see markup freebuff.com renders client-side while it is
 * thinking. That is what this file is for:
 *
 *   1. inject a stylesheet that hides anything with an ad-shaped hook,
 *   2. watch the DOM for ad slots inserted mid-build,
 *   3. collapse the empty wrappers they leave behind.
 *
 * Safety rules this file must never break:
 *   - Never hide <html>, <head>, <body> or any landmark/shell element.
 *   - Never hide a subtree that carries real content (see hasRealContent).
 *   - Never hide the product's own working UI (see LIVE_UI_SELECTOR): the
 *     reasoning toggle, the status line, the progress meter.
 *   - Never fight the build stream: no network activity, no XHR, no fetch.
 *
 * Detection is deliberately three-tiered:
 *   Tier A - explicit hooks (`[data-ad-slot]`, an iframe on an ad host, a
 *            `data-gravity-ad` slot, a `rel="sponsored"` link). Safe to hide
 *            outright; the markup says what it is.
 *   Tier B - attribute *token* matching (`class="ad-slot"` -> tokens
 *            ["ad","slot"]). Tokenised rather than substring matching, because
 *            `[class*="ad"]` also matches header/add/read/load/deadline and
 *            would blank the page. Tier B additionally requires the subtree to
 *            be small, so a section that merely has "ad" in its class name and
 *            holds real content is left alone.
 *   Tier C - in-product promo cards. freebuff.com advertises to itself: a card
 *            with a literal "AD" chip, a headline, body copy and a call to
 *            action, injected straight into the thread. Nothing third-party
 *            loads, and nothing in the markup says "ad", so the badge text is
 *            the only hook there is.
 */
(() => {
  'use strict';

  const STYLE_ID = 'freebuff-focus-style';
  const HIDDEN_CLASS = 'fb-focus-hidden';
  const ENABLED_KEY = 'freebuffFocusEnabled';
  const PING_TYPE = 'freebuff-focus:ping';
  const PICK_TYPE = 'freebuff-focus:pick';
  const CUSTOM_KEY = 'freebuffFocusSelectors';
  const CUSTOM_STYLE_ID = 'freebuff-focus-custom';
  const PICK_BAR_ID = 'freebuff-focus-picker';

  // Read-only legacy names, and the only two words in this file that mention
  // the old product. 1.6 stored its settings and its hidden class under these,
  // so a rename without a read would look like a fresh install to anyone who
  // had already turned the old toggle off - their choice would be silently
  // reset to the default. They are read once, copied to the new names, and
  // removed. Nothing writes them again.
  const LEGACY_ENABLED_KEY = 'freebuffAdBlockEnabled';
  const LEGACY_CUSTOM_KEY = 'freebuffAdBlockSelectors';
  const LEGACY_HIDDEN_CLASS = 'fbad-hidden';
  const LEGACY_STYLE_ID = 'freebuff-adblock-style';
  const PICK_BAR_STYLE =
    'position:fixed;z-index:2147483647;top:12px;left:50%;transform:translateX(-50%);' +
    'background:#0d1017;color:#e9edf5;font:12px/1.4 ui-sans-serif,system-ui,sans-serif;' +
    'padding:8px 14px;border-radius:999px;border:1px solid rgba(157,184,154,.55);' +
    'box-shadow:0 8px 24px rgba(0,0,0,.45);pointer-events:none;';

  // Ad and tracker hosts a free-tier slot is likely to load from.
  const AD_HOSTS = [
    'doubleclick.net',
    'googlesyndication.com',
    'googlesyndication.net',
    'googleadservices.com',
    'adservice.google.com',
    'google-analytics.com',
    'googletagmanager.com',
    'amazon-adsystem.com',
    'media.net',
    'adnxs.com',
    'criteo.com',
    'taboola.com',
    'outbrain.com',
    'pubmatic.com',
    'rubiconproject.com',
    'openx.net',
    'smartadserver.com',
    'yieldmo.com',
    'mgid.com',
    'revcontent.com',
    'casalemedia.com',
    'indexexchange.com',
    'sharethrough.com',
    'triplelift.com',
    'teads.tv',
    'moatads.com',
  ];

  // Tier A - narrow, literal, substring-based. Safe because each fragment is
  // already ad-specific and could not occur in ordinary UI class names.
  const AD_SELECTORS = [
    '[data-ad]',
    '[data-ad-slot]',
    '[data-ad-unit]',
    '[data-ad-container]',
    '[data-ad-client]',
    '[data-google-query-id]',
    // Ad-network hooks. These are the strongest signals in the file: a
    // first-party data attribute written by the ad server itself, the standard
    // sponsored-link rel value, and the ad network's own click endpoint. The
    // in the preview toolbar carries all three and - unlike the promo cards -
    // carries no text label at all, so nothing text-based could have found it.
    // The click path is matched generically, not by host, and the remaining
    // attribute variants are covered by hasNetworkAttribute below - CSS cannot
    // match an attribute *name* prefix, so only the likely spellings are listed
    // here and the rest are caught in script.
    '[data-gravity-ad]',
    '[data-gravity-ad-slot]',
    '[data-gravity-ad-unit]',
    '[data-gravity-sponsored]',
    'a[rel~="sponsored"]',
    'a[href*="/track/click"]',
    '[data-testid*="ad-slot"]',
    '[data-testid*="ad-banner"]',
    '[data-testid*="ad-container"]',
    '[data-testid*="sponsored"]',
    '[class*="ad-banner"]',
    '[class*="ad-slot"]',
    '[class*="ad-unit"]',
    '[class*="ad-container"]',
    '[class*="ad-wrapper"]',
    '[class*="ads-wrapper"]',
    '[class*="ads-container"]',
    '[class*="sponsored-"]',
    '[class*="sponsoredContent"]',
    '[class*="google-auto-placed"]',
    '[id*="ad-container"]',
    '[id*="ad-slot"]',
    '[class*="interstitial"]',
    '[aria-label*="Advertisement"]',
    '[title*="Advertisement"]',
    '.adsbygoogle',
    'ins.adsbygoogle',
  ];

  // Elements that may never receive the hidden class, no matter what they match.
  const NEVER_HIDE_SELECTORS = [
    'html',
    'head',
    'body',
    'main',
    'header',
    'nav',
    'footer',
    'aside',
    '[role="main"]',
    '[role="banner"]',
    '[role="navigation"]',
    '[role="contentinfo"]',
    '[role="complementary"]',
    '[role="log"]',
    '[role="progressbar"]',
    '[role="status"]',
    '[role="alert"]',
    '[role="article"]',
    '[role="region"]',
    '[contenteditable="true"]',
  ].join(', ');

  // The document itself. Every other structural element is refused once by the
  // picker and can then be hidden deliberately (second click); hiding these
  // two leaves nothing on screen to undo it with, so they stay refused.
  const UNHIDEABLE_TAGS = new Set(['HTML', 'HEAD']);

  // Tier B - exact attribute tokens, split on - _ and whitespace.
  const AD_TOKENS = new Set([
    'ad',
    'ads',
    'advert',
    'advertisement',
    'adslot',
    'adunit',
    'adbanner',
    'adcontainer',
    'adsense',
    'adserver',
    'adframe',
    'adsbygoogle',
    'dfp',
    'gpt',
    'sponsored',
    'sponsor',
    'interstitial',
  ]);

  const TOKEN_SOURCE_ATTRS = [
    'class',
    'id',
    'data-testid',
    'data-slot',
    'data-ad-type',
    'aria-label',
    'title',
  ];

  // An element matching only on Tier B heuristics is never hidden if it has
  // more text than an ad unit could carry, or media that did not come from a
  // known ad host. This is the guard that keeps a section with "ad" somewhere
  // in its class name from disappearing.
  const MAX_HEURISTIC_TEXT = 300;

  // Tier C - freebuff.com's own in-product promo cards.
  //
  // These are rendered by freebuff.com itself, so no network rule can reach
  // them, and they carry no ad-shaped class or id - the literal "AD" chip is
  // the only reliable hook, which means this tier reads text where A and B read
  // attributes. Two guards keep that from eating real content:
  //   - the badge must be a leaf element whose entire text is a label like "AD";
  //   - the wrapper found above it must hold a link or a button, must stay
  //     under MAX_PROMO_TEXT characters, and must contain no code or editor.
  const BADGE_LABELS = new Set([
    'ad',
    'ads',
    'advert',
    'advertisement',
    'sponsored',
    'promoted',
  ]);

  const BADGE_LEAF_SELECTOR = 'span, b, strong, em, i, small, sup, mark, abbr, p, div, a';
  const MAX_BADGE_LENGTH = 24;
  const MAX_BADGE_CHILDREN = 2;
  const PROMO_MIN_TEXT = 12;
  const MAX_PROMO_TEXT = 600;
  const MAX_PROMO_DEPTH = 8;
  const MAX_PROMO_ACTIONS = 2;
  const PROMO_ACTION_SELECTOR = 'a[href], button, [role="button"], input[type="submit"]';
  const REAL_CONTENT_SELECTOR =
    'pre, code, textarea, input, [contenteditable="true"], video, audio';

  // Block-level content. A strip of an ad - an icon and a line of copy - holds
  // none of it, and that is what tells a toolbar strip apart from a card.
  const BLOCK_CONTENT_SELECTOR =
    'div, p, section, article, aside, header, footer, main, nav, ul, ol, li, ' +
    'table, form, blockquote, h1, h2, h3, h4, h5, h6';

  // Live app UI - the parts of the page that only exist while the product is
  // working: the progress meter, the status line, the streamed log, and the
  // controls that open a popover. None of it can be part of an ad, so this
  // doubles as a boundary: it stops the card search from climbing out of the ad
  // and into the message, and it stops the wrapper collapse from taking a turn
  // that is about to receive the reasoning toggle and the progress meter.
  const LIVE_UI_SELECTOR =
    '[role="progressbar"], [role="status"], [role="log"], [role="alert"], ' +
    '[aria-haspopup], [contenteditable="true"]';

  const ANY_MEDIA_SELECTOR = 'iframe, embed, object, ins, video, audio, source, img';

  const AD_MEDIA_SELECTOR = AD_HOSTS.map(
    (h) =>
      `iframe[src*="${h}"], img[src*="${h}"], embed[src*="${h}"], ` +
      `object[data*="${h}"], source[src*="${h}"], video[src*="${h}"]`
  ).join(', ');

  const TIER_A_ENTRIES = AD_SELECTORS.concat(
    AD_HOSTS.map((h) => `iframe[src*="${h}"], img[src*="${h}"]`)
  );

  // The stylesheet takes the whole list at once - CSS has no practical length
  // cap. Matching is done in small groups instead, because one enormous
  // selector is a fragile thing: an engine that refuses it rejects every hook
  // in the list at once, silently, which is exactly how the toolbar strip kept
  // its place after the hooks for it already existed.
  const TIER_A_GROUPS = [];
  for (let i = 0; i < TIER_A_ENTRIES.length; i += 5) {
    TIER_A_GROUPS.push(TIER_A_ENTRIES.slice(i, i + 5).join(', '));
  }

  // Hooks the ad network drops *into* a layout row rather than standing on
  // their own - the strip inside the preview toolbar is the one that matters.
  // These must not be taken out of the flow: the row they sit in reflows and
  // everything beside them slides to the left. So the stylesheet empties them
  // where they stand, and the script leaves their slot alone.
  const SLOT_ENTRIES = [
    '[data-gravity-ad]',
    '[data-gravity-ad-slot]',
    '[data-gravity-ad-unit]',
    '[data-gravity-sponsored]',
    'a[rel~="sponsored"]',
    'a[href*="/track/click"]',
  ];

  const SLOT_SELECTOR = SLOT_ENTRIES.join(', ');

  const HIDE_SELECTOR = TIER_A_ENTRIES.filter((e) => !SLOT_ENTRIES.includes(e)).join(', ');

  const CANDIDATE_SELECTOR = TOKEN_SOURCE_ATTRS.map((a) => `[${a}]`).join(', ');

  const css = [
    `${HIDE_SELECTOR} {`,
    '  display: none !important;',
    '  visibility: hidden !important;',
    '}',
    // Invisible, un-clickable, still exactly where it was. The contents go with
    // the box - visibility is inherited - so the ad shows nothing at all while
    // the row keeps the width it had.
    `${SLOT_SELECTOR} {`,
    '  visibility: hidden !important;',
    '  pointer-events: none !important;',
    '}',
    `.${HIDDEN_CLASS} {`,
    '  display: none !important;',
    '  visibility: hidden !important;',
    '}',
  ].join('\n');

  // User-picked selectors, kept separate from everything inferred on our own.
  // These are rules a person made deliberately, so they are applied last and
  // they survive a re-render, a rescue, and anything else in this file.
  const PICK_ATTRS = ['data-gravity-ad', 'data-ad', 'data-ad-slot', 'data-ad-unit', 'data-testid'];

  let customSelectors = [];
  let customStyleEl = null;
  let styleEl = null;
  // Off until storage says otherwise. The store copy promises ads on by
  // default, focus opt-in, and an install that hides before its first read
  // would be that promise broken in the one direction that matters. A 1.6
  // install has a stored value and keeps its choice; a fresh one starts here.
  let enabled = false;
  let observer = null;
  const pending = new Set();
  const pendingBadges = new Set();
  // Elements un-hidden on purpose. Removing our own class is a DOM change like
  // any other, and it reaches the observer looking exactly like a re-render
  // that stripped the class - the re-hide path must not put it straight back.
  const justUnhidden = new Set();
  // Ads neutralised in place instead of hidden. They are still blocked - the
  // stylesheet genuinely removes what you can see - so they belong in the
  // count, but a later scan walks the same element again and must not count it
  // a second time.
  const countedInPlace = new WeakSet();
  let scheduled = false;
  let hiddenThisFlush = 0;
  let hiddenTotal = 0;

  /* ------------------------------------------------------------------ setup */

  function injectStyle() {
    if (styleEl && styleEl.isConnected) return styleEl;
    styleEl = document.getElementById(STYLE_ID);
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = STYLE_ID;
      styleEl.textContent = css;
      (document.head || document.documentElement).appendChild(styleEl);
    }
    styleEl.disabled = !enabled;
    return styleEl;
  }

  function setEnabled(next) {
    const wasEnabled = enabled;
    enabled = !!next;
    if (styleEl) styleEl.disabled = !enabled;
    if (customStyleEl) customStyleEl.disabled = !enabled;
    if (enabled && !wasEnabled && document.body) {
      rescueHidden(document.body);
      sweep(document.body);
    }
  }

  /* ----------------------------------------------------------- token helpers */

  function tokensOf(value) {
    return value ? value.split(/[\s_-]+/).filter(Boolean) : [];
  }

  function hasAdToken(el) {
    for (const attr of TOKEN_SOURCE_ATTRS) {
      const raw = el.getAttribute(attr);
      if (!raw) continue;
      for (const token of tokensOf(raw)) {
        if (AD_TOKENS.has(token.toLowerCase())) return true;
      }
    }
    return false;
  }

  function textLength(el) {
    return (el.textContent || '').replace(/\s+/g, ' ').trim().length;
  }

  // Both of these can be handed a very long generated selector, so they fail
  // closed ("no media found") rather than throwing out of the pass.
  function hasAdMedia(el) {
    try {
      return !!el.querySelector(AD_MEDIA_SELECTOR);
    } catch {
      return false;
    }
  }

  function hasAnyMedia(el) {
    try {
      return !!el.querySelector(ANY_MEDIA_SELECTOR);
    } catch {
      return false;
    }
  }

  function isNeverHidden(el) {
    try {
      return el.matches(NEVER_HIDE_SELECTORS);
    } catch {
      return true;
    }
  }

  /**
   * True when a Tier B (heuristic) match should be left alone because the
   * subtree looks like real page content rather than an ad unit.
   */
  function hasRealContent(el) {
    if (hasAdMedia(el)) return false; // ad-host media inside: it is an ad
    if (hasAnyMedia(el)) return true; // media, but from somewhere legitimate
    return textLength(el) > MAX_HEURISTIC_TEXT;
  }

  /**
   * True when el is, or contains, live app UI. The product's own working parts
   * are never an ad and never part of one, so a wrapper holding them is page
   * structure no matter how small it happens to measure right now.
   */
  function hasLiveUI(el) {
    try {
      return el.matches(LIVE_UI_SELECTOR) || !!el.querySelector(LIVE_UI_SELECTOR);
    } catch {
      return false;
    }
  }

  /* ------------------------------------------------------- user-picked rules */

  function injectCustomStyle() {
    customStyleEl = document.getElementById(CUSTOM_STYLE_ID);
    if (!customStyleEl) {
      customStyleEl = document.createElement('style');
      customStyleEl.id = CUSTOM_STYLE_ID;
      (document.head || document.documentElement).appendChild(customStyleEl);
    }

    customStyleEl.textContent = customSelectors
      .map((selector) => `${selector} { display: none !important; visibility: hidden !important; }`)
      .join(' ');
    customStyleEl.disabled = !enabled;
  }

  function matchesCustom(el) {
    for (const selector of customSelectors) {
      try {
        if (el.matches(selector)) return true;
      } catch {
        // A rule that no longer parses simply stops matching; the rest carry on.
      }
    }
    return false;
  }

  /** Applied last in every pass, so nothing else can undo a deliberate rule. */
  function applyCustom(root) {
    for (const selector of customSelectors) {
      let found;
      try {
        found = root.querySelectorAll(selector);
      } catch {
        continue;
      }
      for (const el of found) hide(el);
    }
  }

  /* ------------------------------------------------------------ promo cards */

  /**
   * True when el's whole text is an ad label.
   *
   * Decided on text rather than on being a leaf, because the chip may hold an
   * icon, and some builds put the label in the same element as the sponsor name
   * ("Baseten AD"). Anything holding more than a label's worth of text is
   * rejected, and the child-count check up front keeps the textContent reads
   * off the bulk of the tree.
   */
  function isBadge(el) {
    if (el.children.length > MAX_BADGE_CHILDREN) return false;
    const raw = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!raw || raw.length > MAX_BADGE_LENGTH) return false;

    const whole = raw.replace(/[^a-z]/gi, '').toLowerCase();
    if (whole !== '' && BADGE_LABELS.has(whole)) return true;

    if (!raw.includes(' ')) return false;
    const last = raw.split(' ').pop().replace(/[^a-z]/gi, '').toLowerCase();
    return BADGE_LABELS.has(last);
  }

  /**
   * True when node is plausibly the card a badge labels: short enough to be a
   * promo unit, with a call to action, and without the code or input fields a
   * real message or the composer would contain.
   */
  function isPromoCard(node) {
    if (isNeverHidden(node)) return false;

    let actions;
    try {
      if (node.querySelector(REAL_CONTENT_SELECTOR)) return false;
      // A card never holds the app's own working UI. This is the guard that
      // keeps the climb out of the message around the card: a turn carrying the
      // progress meter, a status line or a popover control is page structure,
      // not a promo unit, even while those parts have not mounted yet.
      if (hasLiveUI(node)) return false;
      actions = node.querySelectorAll(PROMO_ACTION_SELECTOR).length;
    } catch {
      return false;
    }

    // Two calls to action at most - and none is allowed too. Several of these
    // promos are plain divs with a framework click handler rather than an
    // anchor, so demanding a link misses them, which is how the strip inside the
    // preview toolbar kept its place. The cap is the guard that matters: a
    // wrapper that swallowed the card along with the skill chips or the message
    // buttons under it is well past it, and taking working UI with it is
    // exactly the climb this has to refuse.
    if (actions > MAX_PROMO_ACTIONS) return false;

    const length = textLength(node);
    return length >= PROMO_MIN_TEXT && length <= MAX_PROMO_TEXT;
  }

  /**
   * Climb from a badge to the outermost wrapper that is still only the card.
   * Stops as soon as an ancestor stops looking like one, so the climb cannot
   * escape into the message list or the composer.
   */
  function findPromoCard(badge) {
    let card = null;
    let node = badge.parentElement;
    let depth = 0;

    while (node && node !== document.body && depth < MAX_PROMO_DEPTH) {
      if (isNeverHidden(node)) break;

      // The ad element itself is the hard ceiling. A badge inside a tier A or
      // network-marked element belongs to that element; everything above it is
      // page structure that merely contains the ad. Climbing past this is how
      // the ad's own turn - reasoning toggle and progress meter included - got
      // hidden with it: the wrapper still measured as "small, few actions" a
      // moment before those parts mounted.
      if (matchesTierA(node) || hasNetworkAttribute(node)) {
        card = node;
        break;
      }

      if (isPromoCard(node)) card = node;
      else if (card) break;
      node = node.parentElement;
      depth++;
    }

    return card;
  }

  function hideBadgeCard(el) {
    if (el.nodeType !== Node.ELEMENT_NODE || !isBadge(el)) return;
    const card = findPromoCard(el);
    if (!card) return;
    if (sitsInRow(card)) {
      countInPlace(card);
      return;
    }
    if (hide(card)) collapseUp(card);
  }

  /** Hide every promo card labelled by a badge inside root. */
  function scanBadges(root) {
    hideBadgeCard(root);

    let leaves;
    try {
      leaves = root.querySelectorAll(BADGE_LEAF_SELECTOR);
    } catch {
      return;
    }

    for (const el of leaves) hideBadgeCard(el);
  }

  /* -------------------------------------------------------------- classify */

  /**
   * Tier A match, never throwing: a selector engine limit or a malformed
   * attribute must not abort the pass that hides the ads. Failing open here
   * still leaves tier B and the promo tier running.
   */
  function matchesTierA(el) {
    for (const group of TIER_A_GROUPS) {
      try {
        if (el.matches(group)) return true;
      } catch {
        // A group the engine refuses must not take the others down with it.
      }
    }
    return false;
  }

  /**
   * Attribute *names* an ad network tends to use. A stylesheet cannot match a
   * name prefix, so these are checked in script: a slot marked with
   * `data-gravity-ad-anything` in future is caught without touching the
   * selector list. Every prefix stays ad-specific, so an unrelated
   * `data-gravity-*` attribute on real UI cannot match one.
   */
  const NETWORK_ATTR_PREFIXES = ['data-gravity-ad', 'data-gravity-sponsored', 'data-gravity-promo'];

  function hasNetworkAttribute(el) {
    for (const attr of el.attributes) {
      const name = attr.name;
      if (!name.startsWith('data-')) continue;
      for (const prefix of NETWORK_ATTR_PREFIXES) {
        if (name.startsWith(prefix)) return true;
      }
    }
    return false;
  }

  /** Returns 'a', 'b' or null. */
  function classify(el) {
    if (isNeverHidden(el)) return null;
    if (matchesTierA(el)) return 'a';
    if (hasNetworkAttribute(el)) return 'a';
    if (hasAdToken(el) && !hasRealContent(el)) return 'b';
    return null;
  }

  function hide(el, counted = true) {
    if (el.classList.contains(HIDDEN_CLASS)) return false;
    el.classList.add(HIDDEN_CLASS);
    if (counted) {
      hiddenThisFlush++;
      hiddenTotal++;
    }
    return true;
  }

  /** Count an ad the stylesheet emptied where it stood. */
  function countInPlace(el) {
    if (countedInPlace.has(el)) return;
    countedInPlace.add(el);
    hiddenThisFlush++;
    hiddenTotal++;
  }

  /**
   * True when node lays its children out as a horizontal row - a toolbar, a
   * control strip. Read from computed style rather than from a class name: the
   * page writes these with utility classes, and what makes a row a row is how
   * it lays out, not what it is called.
   */
  function isFlexRow(node) {
    if (!node) return false;
    let style;
    try {
      style = getComputedStyle(node);
    } catch {
      return false;
    }
    if (!style) return false;
    if (style.display !== 'flex' && style.display !== 'inline-flex') return false;
    const direction = style.flexDirection;
    return !direction || direction === 'row' || direction === 'row-reverse';
  }

  /** True when el holds no block-level content: a strip, not a card. */
  function isCompact(el) {
    try {
      return !el.querySelector(BLOCK_CONTENT_SELECTOR);
    } catch {
      return false;
    }
  }

  /**
   * True when el is a strip the page has dropped into an existing layout row.
   * Removing one of these is what pulls the controls beside it to the left, so
   * they keep their box and lose only what is inside it.
   *
   * Both shapes count: the ad is a direct item of a row, or it sits alone in a
   * one-child container that is itself the row item - which is the preview
   * toolbar strip, wrapped in its own `flex w-full` div.
   */
  function sitsInRow(el) {
    if (!isCompact(el)) return false;
    const parent = el.parentElement;
    if (!parent) return false;
    if (isFlexRow(parent)) return true;
    if (parent.children.length > 1) return false;
    return isFlexRow(parent.parentElement);
  }

  /**
   * Walk up from a hidden ad and hide ancestors that contain nothing but the
   * ad itself, reclaiming the blank space a removed slot would leave.
   * Stops at the first ancestor holding real content, at any landmark element,
   * and at a hard depth cap.
   */
  function collapseUp(el) {
    let node = el.parentElement;
    let depth = 0;

    while (node && depth < 6) {
      if (isNeverHidden(node)) break;
      if (hasLiveUI(node)) break;
      // A wrapper that is itself an item in a row is left where it is: the ad
      // inside it is already invisible, and taking the wrapper out of the flow
      // is exactly what drags the row's other controls across to the left.
      if (sitsInRow(node)) break;
      if (!isPureAdWrapper(node)) break;
      hide(node);
      node = node.parentElement;
      depth++;
    }
  }

  function isPureAdWrapper(node) {
    for (const child of node.childNodes) {
      if (child.nodeType === Node.COMMENT_NODE) continue;

      if (child.nodeType === Node.TEXT_NODE) {
        if (child.textContent && child.textContent.trim() !== '') return false;
        continue;
      }

      if (child.nodeType !== Node.ELEMENT_NODE) continue;
      if (child.classList.contains(HIDDEN_CLASS)) continue;
      if (child.tagName === 'BR' || child.tagName === 'HR') continue;
      if (classify(child)) continue;

      return false;
    }
    return true;
  }

  /** Remove the hidden class from el and any hidden ancestors. */
  function unhideFrom(el) {
    let node = el;
    let depth = 0;
    while (node && depth < 8 && node.classList && node.classList.contains(HIDDEN_CLASS)) {
      if (isNeverHidden(node)) break;
      node.classList.remove(HIDDEN_CLASS);
      justUnhidden.add(node);
      node = node.parentElement;
      depth++;
    }
  }

  /**
   * True when an element we already hid still looks like an ad: it matches a
   * tier A hook, or it still carries an ad badge.
   */
  function isStillAd(el) {
    if (matchesTierA(el)) return true;

    let leaves;
    try {
      leaves = el.querySelectorAll(BADGE_LEAF_SELECTOR);
    } catch {
      return false;
    }

    for (const node of leaves) {
      if (isBadge(node)) return true;
    }
    return false;
  }

  /**
   * Real content streamed into a wrapper we already hid means we guessed wrong -
   * put it and its hidden ancestors back so nothing disappears.
   *
   * The exception is the whole reason a promo card used to reappear the moment
   * you sent another prompt: these cards rebuild their own contents on every
   * render, and treating that rebuild as a false positive tore the hide straight
   * back down. A hide only comes off when the element has stopped looking like
   * an ad.
   */
  function rescue(el) {
    const hidden = nearestHiddenAncestor(el);
    if (!hidden) return;
    // A rule someone made by hand is never second-guessed.
    if (matchesCustom(hidden)) return;
    // Live UI inside a wrapper we hid means the hide took real product UI with
    // it. The ad element keeps its own hidden class, so bringing the wrapper
    // back costs nothing, and it is the only way the reasoning toggle and the
    // progress meter can return once they mount inside it.
    if (isStillAd(hidden) && !hasLiveUI(hidden)) return;
    unhideFrom(hidden);
  }

  /** The first ancestor carrying the hidden class, within a small window. */
  function nearestHiddenAncestor(el) {
    let node = el.parentElement;
    let depth = 0;
    while (node && depth < 6) {
      if (node.classList && node.classList.contains(HIDDEN_CLASS)) return node;
      node = node.parentElement;
      depth++;
    }
    return null;
  }

  /* ------------------------------------------------------------------ sweep */

  function process(el, tier) {
    if (!tier) {
      rescue(el);
      return;
    }
    // A strip sitting in a layout row keeps its slot. The stylesheet has
    // already taken it out of sight without moving it, so hiding it here - or
    // collapsing the wrapper around it - is the very thing that reflows the
    // row and shifts everything beside it.
    if (sitsInRow(el)) {
      countInPlace(el);
      return;
    }
    hide(el);
    collapseUp(el);
  }

  /**
   * Classify `root` itself, then everything ad-shaped inside it. This is the
   * core routine: it runs over the whole document once, and over every subtree
   * the page inserts while it is building.
   */
  function scan(root) {
    if (!root || root.nodeType !== Node.ELEMENT_NODE || !root.querySelectorAll) return;

    process(root, classify(root));

    for (const group of TIER_A_GROUPS) {
      let found;
      try {
        found = root.querySelectorAll(group);
      } catch {
        continue;
      }
      for (const el of found) process(el, 'a');
    }

    let candidates;
    try {
      candidates = root.querySelectorAll(CANDIDATE_SELECTOR);
    } catch {
      candidates = [];
    }
    for (const el of candidates) {
      const tier = classify(el);
      if (tier === 'b') process(el, 'b');
    }

    scanBadges(root);
    applyCustom(root);
  }

  /** Full pass: reset counter, scan, report. */
  function sweep(root) {
    hiddenThisFlush = 0;
    scan(root);
    report(hiddenThisFlush);
  }

  /**
   * Self-healing pass. Wrappers hidden earlier may have had legitimate content
   * streamed into them (typically while the extension was toggled off).
   */
  function rescueHidden(root) {
    if (!root || !root.querySelectorAll) return;
    let hidden;
    try {
      hidden = root.querySelectorAll(`.${HIDDEN_CLASS}`);
    } catch {
      return;
    }
    for (const el of hidden) {
      if (isPureAdWrapper(el)) continue;
      unhideFrom(el);
    }
  }

  /* --------------------------------------------------------------- observer */

  function schedule(nodes) {
    for (const node of nodes) {
      // Setting textContent - what React does when it fills in a label after
      // mount - arrives here as a *new text node*, not as a characterData
      // mutation. Dropping those is how a badge gets missed entirely.
      if (node.nodeType === Node.TEXT_NODE) {
        scheduleBadge(node);
        continue;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) continue;
      if (node.id === STYLE_ID) continue;
      pending.add(node);
    }
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(flush);
  }

  /**
   * A badge often shows up as a text change inside markup that was already on
   * the page, which is why the observer listens for characterData too. Those
   * records are checked directly instead of triggering a subtree scan: the page
   * streams text constantly while it builds, and rescanning on every character
   * would be a lot of work for nothing.
   */
  /** True when a class rewrite took our hidden class off an element. */
  function lostHiddenClass(record) {
    const target = record.target;
    if (!target || target.nodeType !== Node.ELEMENT_NODE) return false;
    if (target.classList.contains(HIDDEN_CLASS)) return false;
    return typeof record.oldValue === 'string' && record.oldValue.includes(HIDDEN_CLASS);
  }

  function scheduleBadge(node) {
    const el = node && node.parentElement;
    if (!el) return;
    pendingBadges.add(el);
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(flush);
  }

  function flush() {
    scheduled = false;

    if (!enabled) {
      pending.clear();
      pendingBadges.clear();
      return;
    }

    // The stylesheet is the only thing that actually hides anything. If the page
    // rebuilt its head, every hide already made is silently inert, so check it
    // here instead of trusting that it survived.
    if (!styleEl || !styleEl.isConnected) injectStyle();

    hiddenThisFlush = 0;
    const batch = Array.from(pending);
    pending.clear();

    for (const el of batch) {
      if (!el.isConnected) continue;
      try {
        scan(el);
      } catch {
        // A malformed subtree must never break the page.
      }
    }

    const badges = Array.from(pendingBadges);
    pendingBadges.clear();

    for (const el of badges) {
      if (!el.isConnected) continue;
      try {
        hideBadgeCard(el);
      } catch {
        // Same rule: never let one bad node break the page.
      }
    }

    report(hiddenThisFlush);
  }

  /* --------------------------------------------------------------- reporting */

  function report(count) {
    if (!count) return;
    try {
      const result = chrome.runtime.sendMessage({
        type: 'freebuff-focus:hidden',
        count,
      });
      if (result && typeof result.catch === 'function') result.catch(() => {});
    } catch {
      // Extension context invalidated (reloaded/uninstalled) - ignore.
    }
  }

  /* ------------------------------------------------------------------- state */

  /**
   * Copy a 1.6 setting to its 1.7 name, once. Returns the value to use either
   * way, so the caller never has to care which generation wrote it.
   */
  function migrate(value) {
    const next = {};

    if (typeof value[ENABLED_KEY] !== 'boolean' && typeof value[LEGACY_ENABLED_KEY] === 'boolean') {
      next[ENABLED_KEY] = value[LEGACY_ENABLED_KEY];
    }
    if (!Array.isArray(value[CUSTOM_KEY]) && Array.isArray(value[LEGACY_CUSTOM_KEY])) {
      next[CUSTOM_KEY] = value[LEGACY_CUSTOM_KEY];
    }

    if (Object.keys(next).length === 0) return value;

    try {
      chrome.storage.sync.set(next);
      // remove() is absent in the test harness and present in the browser; a
      // migration that cannot clean up must still migrate.
      if (chrome.storage.sync.remove) chrome.storage.sync.remove([LEGACY_ENABLED_KEY, LEGACY_CUSTOM_KEY]);
    } catch {
      /* the copy above is what matters; the old keys are harmless */
    }

    return { ...value, ...next };
  }

  /**
   * Half a version of history, cleared rather than left in the page: the old
   * stylesheet and the class it hid things with. Without this, elements hidden
   * by 1.6 stay hidden under a class 1.7 never looks at - and they would never
   * come back, which is the one outcome this tool must not produce.
   */
  function clearLegacy() {
    const old = document.getElementById(LEGACY_STYLE_ID);
    if (old) old.remove();
    for (const node of document.querySelectorAll(`.${LEGACY_HIDDEN_CLASS}`)) {
      node.classList.remove(LEGACY_HIDDEN_CLASS);
    }
  }

  function readState() {
    try {
      chrome.storage.sync.get(
        {
          [ENABLED_KEY]: null,
          [CUSTOM_KEY]: null,
          [LEGACY_ENABLED_KEY]: null,
          [LEGACY_CUSTOM_KEY]: null,
        },
        (value) => {
          if (chrome.runtime.lastError) return;
          const state = migrate(value);
          const saved = state[CUSTOM_KEY];
          customSelectors = Array.isArray(saved) ? saved : [];
          injectCustomStyle();
          setEnabled(typeof state[ENABLED_KEY] === 'boolean' ? state[ENABLED_KEY] : false);
        }
      );

      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'sync') return;

        if (Object.prototype.hasOwnProperty.call(changes, CUSTOM_KEY)) {
          const saved = changes[CUSTOM_KEY].newValue;
          customSelectors = Array.isArray(saved) ? saved : [];
          injectCustomStyle();
          if (enabled && document.body) {
            rescueHidden(document.body);
            sweep(document.body);
          }
        }

        if (!Object.prototype.hasOwnProperty.call(changes, ENABLED_KEY)) return;
        setEnabled(changes[ENABLED_KEY].newValue);
      });
    } catch {
      enabled = false;
    }
  }

  /* --------------------------------------------------------------------- go */

  function init() {
    if (document.getElementById(STYLE_ID)) return;

    clearLegacy();
    injectStyle();
    injectCustomStyle();
    readState();

    observer = new MutationObserver((records) => {
      const nodes = [];
      for (const record of records) {
        if (record.type === 'characterData') {
          scheduleBadge(record.target);
          continue;
        }

        // A framework re-render that rewrites className takes our hidden class
        // with it, and the ad is back without a single node being inserted. Put
        // the class straight back rather than rescanning - the old value proves
        // this element was one we hid, and re-adding it fires no further change.
        if (record.type === 'attributes') {
          // A class change we made ourselves is not a re-render.
          if (justUnhidden.delete(record.target)) continue;
          if (lostHiddenClass(record)) hide(record.target, false);
          continue;
        }

        for (const node of record.addedNodes) nodes.push(node);
      }
      if (nodes.length) schedule(nodes);
    });

    const startObserving = () => {
      if (!document.body) return;
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['class'],
        attributeOldValue: true,
      });
      rescueHidden(document.body);
      sweep(document.body);
    };

    if (document.body) startObserving();
    else document.addEventListener('DOMContentLoaded', startObserving, { once: true });
  }

  /* ----------------------------------------------------------------- picking */

  /**
   * The escape hatch, and the only part of this file that cannot be caught out
   * by markup it has never seen. An unrecognised ad is one click away from
   * becoming a rule that holds on every future visit.
   */
  let picking = false;
  let pickBar = null;
  let pickHovered = null;
  let pickHoveredOutline = '';
  // A refused structural element, and how long the offer to override lasts.
  // Hiding `main` or a full-width wrapper is occasionally the whole point -
  // the guard exists to stop accidents, not to overrule the person clicking.
  let confirmTarget = null;
  let confirmUntil = 0;
  const CONFIRM_WINDOW = 5000;

  function isDigit(ch) {
    return ch >= '0' && ch <= '9';
  }

  /**
   * Build the most durable selector we can for an element: a real attribute
   * first, an id second, then any data-* attribute, and only then a structural
   * path - which is the fragile one, so it is the last resort.
   */
  function describeElement(el) {
    const tag = el.tagName.toLowerCase();

    for (const attr of PICK_ATTRS) {
      if (el.hasAttribute(attr)) return `${tag}[${attr}]`;
    }

    const id = el.getAttribute('id');
    if (id && !id.includes(':') && !isDigit(id.charAt(0))) return `#${id}`;

    for (const attr of el.attributes) {
      const name = attr.name;
      if (!name.startsWith('data-')) continue;
      if (name === 'data-state' || name === 'data-slot') continue;
      if (attr.value.length > 40) continue;
      return `${tag}[${name}]`;
    }

    // A tag that appears once in the document is the whole selector. It beats
    // a structural path, which breaks the moment a wrapper is added - and it is
    // what makes `main` or `body` a durable rule rather than a fragile one.
    if (document.getElementsByTagName(tag).length === 1) return tag;

    const path = [];
    let node = el;
    let depth = 0;

    while (node && node !== document.body && depth < 6) {
      let part = node.tagName.toLowerCase();
      const parent = node.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter((sib) => sib.tagName === node.tagName);
        if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(node) + 1})`;
      }
      path.unshift(part);
      node = parent;
      depth++;
    }

    // Body has no ancestors inside the walk, and an element with no attributes
    // still deserves a rule that survives a reload.
    return path.join(' > ') || tag;
  }

  function highlight(el) {
    if (pickHovered === el) return;
    if (pickHovered) pickHovered.style.outline = pickHoveredOutline;
    pickHovered = el;
    if (el) {
      pickHoveredOutline = el.style.outline;
      el.style.outline = '2px solid #9DB89A';
    }
  }

  function pickTarget(event) {
    const el = event.target;
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return null;
    if (el.id === PICK_BAR_ID) return null;
    return el;
  }

  function onPickMove(event) {
    const el = pickTarget(event);
    if (el) highlight(el);
  }

  function onPickClick(event) {
    const el = pickTarget(event);
    if (!el) return;

    // The click belongs to us while picking, not to the page.
    event.preventDefault();
    event.stopPropagation();

    // The document itself is never a target: the page would go blank and take
    // the picker bar with it, so there would be nothing left to click.
    if (UNHIDEABLE_TAGS.has(el.tagName)) {
      if (pickBar) pickBar.textContent = 'That is the document itself - pick something inside it.';
      return;
    }

    if (isNeverHidden(el) || el === document.body) {
      const now = Date.now();
      if (confirmTarget !== el || now >= confirmUntil) {
        confirmTarget = el;
        confirmUntil = now + CONFIRM_WINDOW;
        if (pickBar) {
          pickBar.textContent = 'That is part of the page frame - click it again to hide it anyway.';
        }
        return;
      }
      // Second click on the same element inside the window: consented.
    }

    confirmTarget = null;
    rememberSelector(describeElement(el));
    hide(el);
    stopPicking();
  }

  function onPickKey(event) {
    if (event.key === 'Escape') stopPicking();
  }

  function rememberSelector(selector) {
    if (!selector) return;
    if (customSelectors.includes(selector)) return;

    customSelectors = customSelectors.concat(selector);
    try {
      chrome.storage.sync.set({ [CUSTOM_KEY]: customSelectors });
    } catch {
      // Storage unavailable: the rule still holds for this page.
    }
    injectCustomStyle();
  }

  function startPicking() {
    if (picking) return;
    picking = true;

    pickBar = document.createElement('div');
    pickBar.id = PICK_BAR_ID;
    pickBar.textContent = 'Click the ad to hide it - Esc to cancel';
    pickBar.setAttribute('style', PICK_BAR_STYLE);
    (document.body || document.documentElement).appendChild(pickBar);

    document.addEventListener('mousemove', onPickMove, true);
    document.addEventListener('click', onPickClick, true);
    document.addEventListener('keydown', onPickKey, true);
  }

  function stopPicking() {
    if (!picking) return;
    picking = false;

    document.removeEventListener('mousemove', onPickMove, true);
    document.removeEventListener('click', onPickClick, true);
    document.removeEventListener('keydown', onPickKey, true);

    highlight(null);
    confirmTarget = null;
    confirmUntil = 0;
    if (pickBar && pickBar.parentElement) pickBar.parentElement.removeChild(pickBar);
    pickBar = null;
  }

  /* ------------------------------------------------------------------- ping */

  /**
   * The popup asks a tab whether this script is actually running. Without it,
   * "nothing was found" and "nothing is running" look identical from the
   * outside - which is exactly the confusing case when a tab was already open
   * before the extension was enabled.
   */
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message) return;

    if (message.type === PICK_TYPE) {
      startPicking();
      sendResponse({ ok: true, picking: true });
      return;
    }

    if (message.type !== PING_TYPE) return;
    sendResponse({
      ok: true,
      enabled,
      hidden: hiddenTotal,
      custom: customSelectors.length,
      version: chrome.runtime.getManifest().version,
    });
  });

  init();
})();
