#!/bin/sh
#
# Freebuff Focus for Desktop
#
# Freebuff Desktop renders ads from the orchestrator process it ships inside its
# own .app bundle - `Contents/Resources/orchestrator/orchestrator.js`, run by the
# bundled Bun, not from `app.asar`. A browser extension can never reach it, which
# is why this exists as a separate, local tool.
#
# This script disables the ad runtime in place. It is deliberately boring:
#
#   - It only touches the ad code, at two anchors: the gate the ad auction
#     consults is forced to return "no ads to show", and the ad client's own
#     request helper - the one method every /api/v1/ads/* call goes through - is
#     made to give up before it sends. Nothing else in the file changes.
#   - It refuses to run at all unless every patch anchor is found the exact
#     number of times it expects, and a relaxation is only accepted when ad code
#     sits right beside it. A new Freebuff version that renames a function fails
#     safe and changes nothing, rather than half-patching a 9 MB bundle - and
#     `scan` then shows what that build does contain, so re-anchoring is a
#     report to read instead of a dead end.
#   - It backs up the pristine file before the first write, and `revert` puts it
#     back.
#
# It writes into an app bundle, so macOS App Management has to let your terminal
# do that. If it is blocked, the tool says exactly what to switch on instead of
# failing halfway through a write.
#
# Usage:
#   sh freebuff-focus.sh            # install (the default)
#   sh freebuff-focus.sh status     # report what is applied, change nothing
#   sh freebuff-focus.sh install    # patch, backing up first
#   sh freebuff-focus.sh focus      # quiet until you run unfocus
#   sh freebuff-focus.sh focus 25m  # quiet until the deadline, then restored
#   sh freebuff-focus.sh focus session  # quiet until Freebuff quits
#   sh freebuff-focus.sh verify     # wait for the relaunch, check what it loaded
#   sh freebuff-focus.sh revert     # restore the pristine backup
#   sh freebuff-focus.sh doctor     # environment report for a bug report
#   sh freebuff-focus.sh scan       # show the anchors this build has (for a re-anchor)
#
#   --app PATH          the Freebuff.app to patch (default: /Applications)
#   --display-only      skip the ad-API anchor (leave the render gate only)
#   --dry-run           with install: report what would happen, write nothing
#   --backup-dir PATH   where the pristine copy lives
#   --resign            ad-hoc re-sign the bundle after patching
#   --no-wait           verify: report now instead of waiting for a relaunch
#   --timeout SECONDS   verify: how long to wait (default 300)
#
# Every Freebuff update replaces Contents/Resources, so the patch is gone after
# one. Run `install` again after an update.
#
# The patch is only half the answer: the orchestrator is read once at launch, so
# a patched file with an old process in memory is a patched file doing nothing.
# `verify` is the other half - it waits for the relaunch and then checks that the
# process running now started after the patch was written. `install` runs it for
# you when Freebuff is open. Both are read-only.
#
# MIT licensed. See LICENSE.

set -u

# Stamped at build time (scripts/build-desktop.mjs).
VERSION="1.12.0"
# The test suite points this at a file:// copy so update can be exercised without
# the network. Nothing else sets it.
ORIGIN="${FREEBUFF_FOCUS_ORIGIN:-https://freebuff-focusmode.vercel.app}"

# Whether this run has the script on disk. `curl | sh` does not, so a hint that
# says "sh freebuff-focus.sh status" would point at a file that is not there.
HAVE_LOCAL=0
[ -f "${0:-}" ] && HAVE_LOCAL=1

# Where the tool lives once it installs itself, and the command that finds it.
# The install folder doubles as the session folder - one small directory, two
# files, nothing to clean up twice.
INSTALL_DIR="${FREEBUFF_FOCUS_HOME:-${XDG_DATA_HOME:-$HOME/.local/share}/freebuff-focus}"
BIN_DIR="${FREEBUFF_FOCUS_BIN_DIR:-$HOME/.local/bin}"
COMMAND_NAME="freebuff-focusmode"
# The short form, written beside the long one on setup and removed with it on
# uninstall. Both names run the same installed file.
ALIAS_NAME="freebuff-focus"
INSTALLED_SELF="$INSTALL_DIR/freebuff-focus.sh"

# The backup folder keeps its 1.6 name on purpose: renaming it would orphan every
# pristine copy an existing install already wrote, and those are exactly what
# `revert` restores. The override is new; the old one still works.
BACKUP_DIR="${FREEBUFF_FOCUS_BACKUP_DIR:-$HOME/freebuff-patch-backups}"
# Where a focus session is recorded. One small file, no daemon: the session ends
# when its timestamp passes, whether or not this tool is ever run again.
SESSION_DIR="${FREEBUFF_FOCUS_SESSION_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/freebuff-focus}"
APP="${FREEBUFF_APP:-}"
DEEP=1
DRY=0
RESIGN=0
# auto   - restart only when Freebuff was open when the patch was written
# always - quit and relaunch even when it was closed (--restart)
# never  - never touch a process (--no-restart)
RESTART=auto
FOCUS_ARG=""
# The watcher `focus 25m` and `focus session` start. The arguments below are only
# set by `__watch`, which is how the tool re-invokes itself - it is not a command
# anyone types, and it is deliberately absent from the command list and the help.
INTERVAL=1
WATCH_RUN=""
WATCH_TARGET=""
WATCH_BACKUP=""
WATCH_STAMP=""
WATCH_MODE=""
WATCH_PID=""
WATCH_ENDS=""
# Waiting is the point of `verify`, and it is only ever done when Freebuff is
# open - a closed app has no relaunch to observe, and an unattended install must
# not sit here. The wait is bounded anyway, and Ctrl-C stops it.
WAIT=1
WAIT_SECS=300
COMMAND=""
# setup --add-path: append the bin folder to the shell rc instead of printing the
# line for the reader to paste. Opt-in, because it edits a dotfile.
ADD_PATH=0
# update --force: reinstall even when the version already matches.
FORCE=0

if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then
  B="$(printf '\033[1m')"; DIM="$(printf '\033[2m')"; GREEN="$(printf '\033[32m')"
  RED="$(printf '\033[31m')"; YELLOW="$(printf '\033[33m')"; OFF="$(printf '\033[0m')"
else
  B=""; DIM=""; GREEN=""; RED=""; YELLOW=""; OFF=""
fi

say() { printf '%s\n' "$*"; }
ok() { printf '  %s%s%s %s\n' "$GREEN" "ok" "$OFF" "$*"; }
warn() { printf '  %s%s%s %s\n' "$YELLOW" "!" "$OFF" "$*"; }
bad() { printf '  %s%s%s %s\n' "$RED" "x" "$OFF" "$*"; }
die() { printf '%s%serror:%s %s\n' "$B" "$RED" "$OFF" "$*" >&2; exit 1; }
hr() { printf '%s\n' "${DIM}--------------------------------------------${OFF}"; }

# How a hint names this tool: the installed command when it exists, the local file
# otherwise. Someone who ran the one-liner should be told to use what it created.
cmdname() {
  if [ -x "$BIN_DIR/$COMMAND_NAME" ]; then printf '%s' "$COMMAND_NAME"
  else printf '%s' "sh freebuff-focus.sh"
  fi
}

# ------------------------------------------------------------------- arg parse

while [ $# -gt 0 ]; do
  case "$1" in
    install|status|verify|revert|doctor|diagnose|scan|focus|unfocus|help|version) COMMAND="$1"; shift ;;
    setup|update|uninstall) COMMAND="$1"; shift ;;
    __watch) COMMAND="__watch"; shift ;;
    --interval|--watch-run|--watch-target|--watch-backup|--watch-stamp|--watch-mode|--watch-pid|--watch-ends)
      key="${1#--}"; shift
      [ $# -gt 0 ] || die "--$key needs a value"
      case "$key" in
        interval)     INTERVAL="$1" ;;
        watch-run)    WATCH_RUN="$1" ;;
        watch-target) WATCH_TARGET="$1" ;;
        watch-backup) WATCH_BACKUP="$1" ;;
        watch-stamp)  WATCH_STAMP="$1" ;;
        watch-mode)   WATCH_MODE="$1" ;;
        watch-pid)    WATCH_PID="$1" ;;
        watch-ends)   WATCH_ENDS="$1" ;;
      esac
      shift ;;
    --app=*) APP="${1#--app=}"; shift ;;
    --backup-dir=*) BACKUP_DIR="${1#--backup-dir=}"; shift ;;
    --session-dir=*) SESSION_DIR="${1#--session-dir=}"; shift ;;
    --app) shift; [ $# -gt 0 ] || die "--app needs a path"; APP="$1"; shift ;;
    --backup-dir) shift; [ $# -gt 0 ] || die "--backup-dir needs a path"; BACKUP_DIR="$1"; shift ;;
    --session-dir) shift; [ $# -gt 0 ] || die "--session-dir needs a path"; SESSION_DIR="$1"; shift ;;
    --display-only) DEEP=0; shift ;;
    --deep) DEEP=1; shift ;;
    --dry-run) DRY=1; shift ;;
    --resign) RESIGN=1; shift ;;
    --restart) RESTART=always; shift ;;
    --no-restart) RESTART=never; shift ;;
    --no-wait) WAIT=0; shift ;;
    --add-path) ADD_PATH=1; shift ;;
    --force) FORCE=1; shift ;;
    --timeout) shift; [ $# -gt 0 ] || die "--timeout needs a number of seconds"; WAIT_SECS="$1"; shift ;;
    --timeout=*) WAIT_SECS="${1#--timeout=}"; shift ;;
    -h|--help) COMMAND=help; shift ;;
    --version) COMMAND=version; shift ;;
    *)
      # `focus 25m` - the duration is the one positional argument this tool
      # takes, and only focus takes it.
      if [ "$COMMAND" = "focus" ] && [ -z "$FOCUS_ARG" ]; then FOCUS_ARG="$1"; shift
      else die "unknown argument: $1  (try --help)"
      fi ;;
  esac
done

case "$WAIT_SECS" in
  ''|*[!0-9]*) die "--timeout needs a number of seconds, not '$WAIT_SECS'" ;;
esac
case "$INTERVAL" in
  ''|*[!0-9]*) die "--interval needs a number of seconds, not '$INTERVAL'" ;;
esac
[ "$INTERVAL" -ge 1 ] || INTERVAL=1

[ -n "$COMMAND" ] || COMMAND=install

# --------------------------------------------------------------------- helpers

find_app() {
  if [ -n "$APP" ]; then
    [ -d "$APP/Contents/Resources/orchestrator" ] || die "not a Freebuff app bundle: $APP"
    printf '%s\n' "$APP"
    return 0
  fi
  for candidate in "/Applications/Freebuff.app" "$HOME/Applications/Freebuff.app"; do
    if [ -d "$candidate/Contents/Resources/orchestrator" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done
  return 1
}

app_version() {
  plist="$1/Contents/Info.plist"
  if [ -x /usr/libexec/PlistBuddy ] && [ -f "$plist" ]; then
    v="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$plist" 2>/dev/null || true)"
    if [ -n "$v" ]; then printf '%s' "$v"; return 0; fi
  fi
  if [ "$(uname -s)" = "Darwin" ] && [ -f "$plist" ]; then
    v="$(defaults read "$plist" CFBundleShortVersionString 2>/dev/null || true)"
    if [ -n "$v" ]; then printf '%s' "$v"; return 0; fi
  fi
  printf 'unknown'
}

app_running() {
  command -v pgrep >/dev/null 2>&1 || return 1
  pgrep -x Freebuff >/dev/null 2>&1
}

#
# The relaunch check.
#
# `status` and `scan` read a file, and a file cannot say whether the app you are
# looking at is running it. The orchestrator is read once at launch, so the one
# honest test is a comparison of two times: when the patch was written, and when
# the process that is running now started. Started later means the patched file
# is what it read. Nothing here writes anything and nothing here leaves the
# machine.

# Every orchestrator process running out of this bundle. The path is the app's
# own, so a bundle patched with --app is matched too.
orchestrator_pids() {
  command -v pgrep >/dev/null 2>&1 || return 1
  want="$1/Contents/Resources/orchestrator/orchestrator.js"
  for pid in $(pgrep -f "$want" 2>/dev/null); do
    # `pgrep -f` matches any command line that merely *mentions* the path - a
    # `tail -f` on it, an editor, a shell whose arguments name it. Only the
    # process actually running the file ends with it, and only that one is the
    # orchestrator. Without this, a check that happened to name the path would
    # find itself and call the app verified.
    cmd="$(ps -p "$pid" -o command= 2>/dev/null | sed 's/[[:space:]]*$//')"
    case "$cmd" in
      *"$want") printf '%s\n' "$pid" ;;
    esac
  done
}

# ---------------------------------------------------------------- relaunching
#
# A patch on disk is not a patch in effect, and 1.6 answered that with an
# instruction - "quit it completely and reopen it" - which was the one step
# people skipped. 1.7 does it: ask the app to quit, then SIGTERM, then SIGKILL,
# then start it again and watch for the process that proves it read the file.
# That order is macOS's own, not an invention; nothing here needs sudo.

quit_app() {
  app="$1"
  [ -n "$(orchestrator_pids "$app")" ] || return 0

  if command -v osascript >/dev/null 2>&1; then
    osascript -e 'tell application "Freebuff" to quit' >/dev/null 2>&1 || true
  fi

  # Five seconds to honour a quit request is generous for an app that is idle,
  # and short enough that a stuck one does not hold the terminal for long.
  waited=0
  while [ -n "$(orchestrator_pids "$app")" ] && [ "$waited" -lt 5 ]; do
    sleep 1; waited=$(( waited + 1 ))
  done

  for sig in TERM KILL; do
    pids="$(orchestrator_pids "$app")"
    [ -n "$pids" ] || return 0
    for pid in $pids; do kill -"$sig" "$pid" 2>/dev/null || true; done
    waited=0
    while [ -n "$(orchestrator_pids "$app")" ] && [ "$waited" -lt 5 ]; do
      sleep 1; waited=$(( waited + 1 ))
    done
  done

  # The orchestrator going away is not the app going away. A bundle that dies
  # while loading its own resources leaves the main process behind with no
  # window, and that process holds the instance lock the next launch needs.
  waited=0
  while [ -n "$(app_pids "$app")" ] && [ "$waited" -lt 3 ]; do
    sleep 1; waited=$(( waited + 1 ))
  done
  for pid in $(app_pids "$app"); do kill -TERM "$pid" 2>/dev/null || true; done
  sleep 1
  for pid in $(app_pids "$app"); do kill -KILL "$pid" 2>/dev/null || true; done

  [ -z "$(orchestrator_pids "$app")" ] && [ -z "$(app_pids "$app")" ]
}

launch_app() {
  command -v open >/dev/null 2>&1 || return 1
  open -a "$1" >/dev/null 2>&1
}

# ------------------------------------------------------ started, or handed over
#
# `open -a` answers for LaunchServices, not for the app: it returns 0 the moment
# macOS accepts the handover, which is before one line of the bundle has run. A
# bundle that dies while loading its own resources therefore looks exactly like
# one that opened - and that is the shape of "it closes and does not come back",
# the one failure that leaves the reader with no app at all. So every restart is
# watched, and a restart that did not take is looked into before anything is
# claimed about it.

# The bundle's own executable. `open` starts this one; the helpers under
# Frameworks belong to a launch, they are not one.
app_binary() {
  dir="$1/Contents/MacOS"
  [ -d "$dir" ] || return 1
  for f in "$dir"/*; do
    [ -f "$f" ] && [ -x "$f" ] && { printf '%s\n' "$f"; return 0; }
  done
  return 1
}

# Every process whose command is this bundle's executable. Same rule as
# orchestrator_pids: `pgrep -f` matches anything that merely names the path.
app_pids() {
  bin="$(app_binary "$1")" || return 1
  command -v pgrep >/dev/null 2>&1 || return 1
  for pid in $(pgrep -f "$bin" 2>/dev/null); do
    [ "$pid" = "$$" ] && continue
    cmd="$(ps -p "$pid" -o command= 2>/dev/null | sed 's/[[:space:]]*$//')"
    case "$cmd" in
      "$bin"|"$bin "*) printf '%s\n' "$pid" ;;
    esac
  done
}

# 0 as soon as anything of this bundle is running, 1 after the whole wait.
wait_app() {
  app="$1"; secs="${2:-20}"
  waited=0
  while :; do
    alive=0
    [ -n "$(orchestrator_pids "$app")" ] && alive=1
    [ -n "$(app_pids "$app")" ] && alive=1
    if [ "$alive" = "1" ]; then
      # A process that appears and is gone a moment later is a launch that dies
      # while loading, which is what "it closes and never comes back" looks like
      # from outside. Treating the first sighting as success would call that a
      # restart and leave the reader with nothing.
      grace="${FREEBUFF_FOCUS_GRACE_SECS:-3}"
      [ "$grace" = "0" ] && return 0
      sleep "$grace"
      if [ -n "$(orchestrator_pids "$app")" ] || [ -n "$(app_pids "$app")" ]; then
        return 0
      fi
      waited=$(( waited + grace ))
      continue
    fi
    [ "$waited" -ge "$secs" ] && return 1
    sleep 1; waited=$(( waited + 1 ))
  done
}

# 0 when the app is running again, 1 when it could not be brought back. Says
# nothing on success: the caller owns the wording, and `verify` owns the proof.
restart_app() {
  app="$1"
  quit_app "$app" || return 1
  launch_app "$app" || return 1
  wait_app "$app" "${FREEBUFF_FOCUS_WAIT_APP:-20}"
}

# Where the next direct start keeps what the app says about itself.
launch_log() { printf '%s/launch.log\n' "$SESSION_DIR"; }

# Start the bundle's executable by hand, output and all, and watch it for a few
# seconds. `open` throws that output away, and the line explaining a refusal to
# load is the whole reason to do this the direct way. 1 does not mean the bundle
# is broken: macOS SIGKILLs a hand-started copy of some bundles while the same
# bundle opens from Finder, so PROBE_KILLED carries that apart for the caller.
probe_direct() {
  app="$1"
  bin="$(app_binary "$app")" || return 1
  log="$(launch_log)"
  mkdir -p "$SESSION_DIR" 2>/dev/null || true
  : > "$log" 2>/dev/null || true
  "$bin" >>"$log" 2>&1 &
  pid=$!
  waited=0
  while [ "$waited" -lt "${FREEBUFF_FOCUS_PROBE_SECS:-10}" ]; do
    sleep 1; waited=$(( waited + 1 ))
    kill -0 "$pid" 2>/dev/null || break
  done
  kill -0 "$pid" 2>/dev/null && return 0
  wait "$pid" 2>/dev/null
  code=$?
  if [ "$code" = "137" ] || [ "$code" = "9" ]; then PROBE_KILLED=1; fi
  return 1
}

# Did this bundle start? The direct start answers it and keeps the app's own
# output, but a killed direct start is macOS minding how it was started, not the
# bytes - the same bundle opens from Finder. So it is followed by the launch a
# reader would make, and only both of them failing is an answer about the bundle.
# PROBE_MODE says which one settled it, for the wording.
probe_start() {
  app="$1"
  PROBE_KILLED=0
  if probe_direct "$app"; then
    PROBE_MODE=direct
    return 0
  fi
  quit_app "$app" >/dev/null 2>&1 || true
  if launch_app "$app" >/dev/null 2>&1; then
    if wait_app "$app" "${FREEBUFF_FOCUS_PROBE_SECS:-10}"; then
      PROBE_MODE=open
      return 0
    fi
  fi
  PROBE_MODE=none
  return 1
}

# The most telling line the app printed, for a reader who cannot read the log.
launch_reason() {
  log="$(launch_log)"
  [ -s "$log" ] || return 0
  line="$(grep -m1 -E 'Error|error|FATAL|fatal|Exception|denied|invalid|not found|abort|refus' "$log" 2>/dev/null | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
  [ -n "$line" ] || line="$(tail -n 2 "$log" 2>/dev/null | tr '\n' ' ' | sed 's/[[:space:]]*$//')"
  [ -n "$line" ] && printf '%s\n' "$line" | cut -c1-150
}

# A patch changes app.asar, and app.asar is one of the files the bundle's own
# signature covers. A Mac that enforces that refuses to launch the modified copy,
# which looks exactly like "the patch is broken". These answer it; 1 from
# signature_ok also means only that nothing here can repair the signature.
signature_ok() {
  command -v codesign >/dev/null 2>&1 || return 1
  codesign --verify --strict "$1" >/dev/null 2>&1
}

resign_app() {
  command -v codesign >/dev/null 2>&1 || return 1
  codesign --force --deep --sign - "$1" >/dev/null 2>&1
}

signature_word() {
  if ! command -v codesign >/dev/null 2>&1; then
    printf 'unknown (no codesign)\n'
  elif signature_ok "$1"; then
    printf 'valid\n'
  else
    printf 'broken - a written file is covered by it\n'
  fi
}

# The last lines the app printed for itself, which is where a refusal says what it
# refused. launch_reason picks one line for a summary; a reader who cannot open
# the log needs the few around it too.
launch_tail() {
  log="$(launch_log)"
  [ -s "$log" ] || return 0
  grep -v '^[[:space:]]*$' "$log" 2>/dev/null | tail -n "${1:-3}" | cut -c1-160
}

# Put app.asar and Info.plist back the way the bundle shipped, then open it.
# Only for bytes that have just been shown not to start: an app that will not
# open is worse than an app with ads in it, and the ads can come off again once
# the reason is known.
window_rollback() {
  app="$1"; version="$2"
  asar="$app/Contents/Resources/app.asar"
  plist="$app/Contents/Info.plist"
  backup="$BACKUP_DIR/app.asar.$version.orig"
  plist_backup="$BACKUP_DIR/Info.plist.$version.orig"
  [ -f "$backup" ] || return 1
  cp "$backup" "$asar" 2>/dev/null || return 1
  if [ -f "$plist_backup" ]; then cp "$plist_backup" "$plist" 2>/dev/null || true; fi
  # An install that never kept the plist still needs it to describe this asar.
  shell_sync_integrity "$app" >/dev/null 2>&1 || true
  # A session would keep a watcher alive for a run that never started, and it
  # would restore a file the ads are already back in.
  stop_watcher
  rm -f "$(session_file)" 2>/dev/null || true
  quit_app "$app" >/dev/null 2>&1 || true
  # Opening it is the point of putting it back, but the caller reports on the
  # files, so a slow launch here is not a failure of the rollback.
  launch_app "$app" >/dev/null 2>&1 || true
  return 0
}

# The restart did not take. Two causes look the same from here and only one of
# them is a property of the patch: a launch that is merely slow, and a bundle
# that refuses the bytes this tool wrote. A direct start separates them, and only
# the second puts app.asar back. 0 when Freebuff ends up running, 1 when it does
# not - including the rollback, which reopens a working app with ads on.
rescue_app() {
  app="$1"; version="$2"
  # Without the bundle's own executable there is no way to tell a slow launch
  # from a refused one, and guessing would undo a patch that may be fine.
  app_binary "$app" >/dev/null 2>&1 || return 1
  quit_app "$app" >/dev/null 2>&1 || true
  if probe_start "$app"; then
    rm -f "$SESSION_DIR/launch.failed" 2>/dev/null || true
    ok "started Freebuff"
    return 0
  fi
  reason="$(launch_reason)"
  state="$(shell_state "$app")"
  patched=0
  case "$state" in patched|partial) patched=1 ;; esac

  # Patching app.asar changes a file the bundle's signature covers, and a strict
  # Mac kills that copy at launch. The start is repeated once with the bundle
  # signed ad-hoc: when that is all it wanted, the patch stays and the ads stay
  # off. Only a second failure puts the pristine bytes back.
  if [ "$patched" = "1" ] && [ "${FREEBUFF_FOCUS_RESIGN:-1}" = "1" ] \
     && ! signature_ok "$app" && resign_app "$app"; then
    if probe_start "$app"; then
      ok "it started once the bundle was signed again"
      say "  ${DIM}This bundle is signed, and app.asar is one of the files that${OFF}"
      say "  ${DIM}signature covers, so macOS refused the patched copy for it. It${OFF}"
      say "  ${DIM}is signed ad-hoc now, which still starts. The patch is in place.${OFF}"
      return 0
    fi
  fi
  if [ "$patched" = "1" ] && window_rollback "$app" "$version"; then
    printf '%s\n' "${reason:-it exited without a message}" > "$SESSION_DIR/launch.failed" 2>/dev/null || true
    warn "Freebuff would not start with the window stage applied, so app.asar and Info.plist were put back exactly as they were"
    [ -n "$reason" ] && say "  Freebuff said: ${DIM}$reason${OFF}"
    launch_tail | while IFS= read -r line; do say "  ${DIM}$line${OFF}"; done
    if [ "${PROBE_KILLED:-0}" = "1" ]; then
      say "  ${DIM}macOS killed the start this tool makes by hand (Killed: 9) - a normal${OFF}"
      say "  ${DIM}launch did not keep it open either, so the bytes are the question.${OFF}"
    fi
    if [ -n "$(app_pids "$app")" ] || [ -n "$(orchestrator_pids "$app")" ]; then
      say "  It is open again, with ads. Nothing in the bundle is half-written:"
      say "  the window stage is gone and the rest of the patch is untouched."
    else
      say "  Open Freebuff again - the bundle is exactly the one you installed,"
      say "  ads and all. Nothing in it is half-written."
    fi
    say "  The app's own output is kept in $(launch_log)"
    return 0
  fi
  printf '%s\n' "${reason:-it exited without a message}" > "$SESSION_DIR/launch.failed" 2>/dev/null || true
  if [ "$patched" = "1" ]; then
    # The backup is what makes the rollback possible, and only one keyed to the
    # version now installed is a copy of these bytes. Without it there is nothing
    # safe to put back, so say so instead of leaving the reader with a dead app
    # and no next step.
    warn "Freebuff did not start, and the window stage could not be put back"
    [ -n "$reason" ] && say "  Freebuff said: ${DIM}$reason${OFF}"
    say "  There is no pristine app.asar.$version.orig in $BACKUP_DIR."
    if [ -d "$BACKUP_DIR" ]; then
      for f in "$BACKUP_DIR"/app.asar.*.orig; do
        [ -f "$f" ] && say "  ${DIM}(a backup for another version is there: $f)${OFF}"
      done
    fi
    say "  Put the official build back and Freebuff will start:"
    say "    https://freebuff.com/desktop"
    say "  Then run: $(cmdname) install - it keeps the backup it needs from then on."
    say "  The app's own output is kept in $(launch_log)"
    return 1
  fi
  # fallthrough: not this tool's stage that stopped it, so nothing is undone.
  warn "Freebuff did not start, and nothing this tool wrote was rolled back"
  if [ -n "$reason" ]; then
    say "  Freebuff said: ${DIM}$reason${OFF}"
  else
    bin="$(app_binary "$app" 2>/dev/null)"
    if [ "${PROBE_KILLED:-0}" = "1" ]; then
      say "  macOS killed the start this tool made by hand (${B}Killed: 9${OFF}), and a"
      say "  normal launch did not keep it open either."
    else
      say "  It printed nothing. Start it by hand to see why:"
      say "    ${bin:-$app/Contents/MacOS/Freebuff}"
    fi
  fi
  say "  If it still will not open, put the pristine files back: $(cmdname) revert"
  say "  The app's own output is kept in $(launch_log)"
  return 1
}
# Nothing is running and the window stage is in the bundle, so the one thing a
# file check cannot answer - whether this bundle starts at all - is answered by
# starting it, and the stage is undone if it will not. `--no-restart` is the way
# out for anyone who does not want the tool opening the app.
# A restart is only a restart if the app is still up a few seconds later. The
# bundle that dies on a patch dies after it has booted - it gets through its
# phases, then quits - so a process seen and gone within the same second proves
# nothing. 0 when something of the bundle is still running, 1 when it is not,
# with app.asar put back in the same breath.
confirm_started() {
  app="$1"; version="$2"
  sleep "${FREEBUFF_FOCUS_SETTLE_SECS:-4}"
  [ -n "$(app_pids "$app")" ] && return 0
  [ -n "$(orchestrator_pids "$app")" ] && return 0
  rescue_app "$app" "$version" || true
  return 1
}

ensure_starts() {
  app="$1"; version="$2"
  [ "$RESTART" = "never" ] && return 0
  # Nothing can be started here - no `open`, or a bundle laid out differently -
  # so a failed launch would say nothing about the patch and must not undo it.
  command -v open >/dev/null 2>&1 || return 0
  app_binary "$app" >/dev/null 2>&1 || return 0
  [ -z "$(orchestrator_pids "$app")" ] || return 0
  [ -z "$(app_pids "$app")" ] || return 0
  case "$(shell_state "$app")" in patched|partial) : ;; *) return 0 ;; esac
  say "  ${DIM}Checking that Freebuff still starts with this in place…${OFF}"
  launch_app "$app" >/dev/null 2>&1 || true
  if wait_app "$app" "${FREEBUFF_FOCUS_WAIT_APP:-20}"; then
    ok "it started"
    return 0
  fi
  rescue_app "$app" "$version"
}

# A process that started before the patch was written is still running the old
# bytes. Both seconds come from ps, so the same two-second tolerance `verify`
# uses applies here; without it a just-launched app reads as stale.
stale_process() {
  app="$1"; target="$2"
  mtime="$(file_mtime "$target")" || return 1
  for pid in $(orchestrator_pids "$app"); do
    started="$(proc_start_epoch "$pid")" || continue
    [ "$started" -lt "$(( mtime - 2 ))" ] && return 0
  done
  return 1
}

# ------------------------------------------------------------- focus sessions
#
# A focus is one small file, and its three modes differ only in what ends it:
#
#   focus           mode=until-unfocus  nothing does. `unfocus` puts the pristine
#                                       file back when the reader asks it to.
#   focus 25m       mode=until          a deadline. A watcher restores the file
#                                       when it passes, so the next launch of
#                                       Freebuff has ads again.
#   focus session   mode=session        the app. The watcher restores the file as
#                                       the orchestrator it watches exits, so
#                                       reopening Freebuff later shows ads.
#
# "The ads come back when this run of the app ends" cannot be a timestamp: the
# orchestrator is read once at launch, so something has to put the pristine file
# back. That is the watcher - one detached `sh` per timed or session focus,
# polling, and gone the moment what it waits for happens. `unfocus` stops it, a
# session file that no longer carries its run token makes it stand down, and it
# writes nothing at all if the file changed after the patch (a Freebuff update, a
# fresh install), so it can never clobber a patch someone else made. Plain
# `focus` is the only mode that leaves nothing running.

# Seconds, or nothing. There is no default any more: `focus` with no argument
# means "until unfocus", so guessing a duration here would contradict the reader.
# 25m, 90m, 2h, 45 (minutes) and 45s all parse; anything else is refused.
duration_seconds() {
  raw="${1:-}"
  [ -n "$raw" ] || return 1
  unit=60
  case "$raw" in
    *s) n="${raw%s}"; unit=1 ;;
    *m) n="${raw%m}" ;;
    *h) n="${raw%h}"; unit=3600 ;;
    *[!0-9]*) return 1 ;;
    *)  n="$raw" ;;
  esac
  case "$n" in ''|*[!0-9]*) return 1 ;; esac
  secs=$(( n * unit ))
  [ "$secs" -ge 5 ] || return 1
  [ "$secs" -le 86400 ] || return 1
  printf '%s' "$secs"
}

clock_at() {
  if [ "$(uname -s)" = "Darwin" ]; then
    date -r "$1" '+%H:%M' 2>/dev/null || printf '?'
  else
    date -d "@$1" '+%H:%M' 2>/dev/null || printf '?'
  fi
}

session_file() {
  printf '%s/session' "$SESSION_DIR"
}

# One key out of the session file. Fails when there is no file at all, so a
# caller can tell "no session" apart from "a session with an empty value".
session_get() {
  file="$(session_file)"
  [ -f "$file" ] || return 1
  sed -n "s/^$1=//p" "$file" 2>/dev/null | head -n 1
}

# Replace one key, adding it when it is not there yet. With a third argument the
# write only happens while the file still belongs to that run: a watcher may
# record its own pid, but it may never edit a session that has been replaced.
session_set() {
  key="$1"; val="$2"; token="${3:-}"
  file="$(session_file)"
  [ -f "$file" ] || return 1
  if [ -n "$token" ] && [ "$(session_get run || true)" != "$token" ]; then return 1; fi
  tmp="$file.tmp.$$"
  awk -v k="$key" -v v="$val" '
    BEGIN { done = 0 }
    $0 ~ ("^" k "=") { print k "=" v; done = 1; next }
    { print }
    END { if (!done) print k "=" v }
  ' "$file" > "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
  mv "$tmp" "$file"
}

# Which of the three a session is. A 1.8.0 file has an end time and no mode, and
# it meant the same thing a timed focus means now.
session_mode() {
  mode="$(session_get mode || true)"
  if [ -z "$mode" ]; then
    if [ -n "$(session_ends || true)" ]; then mode=until; else mode=until-unfocus; fi
  fi
  printf '%s' "$mode"
}

session_ends() {
  [ -f "$(session_file)" ] || return 1
  sed -n 's/^endsAt=//p' "$(session_file)" 2>/dev/null | head -n 1
}

# Whether the process that is supposed to end this focus is still there.
watch_alive() {
  wpid="$(session_get watcher || true)"
  case "$wpid" in ''|*[!0-9]*) return 1 ;; esac
  kill -0 "$wpid" 2>/dev/null
}

# One line in status: what kind of focus is on, and what will end it. Silent when
# there is no session file at all, because most runs have nothing to say.
session_line() {
  [ -f "$(session_file)" ] || return 0
  case "$(session_mode)" in
    until-unfocus)
      say "  focus    on - until you run: $(cmdname) unfocus"
      ;;
    session)
      pid="$(session_get pid || true)"
      if [ -z "$pid" ]; then
        say "  focus    on - until Freebuff quits (waiting for it to open)"
      elif kill -0 "$pid" 2>/dev/null; then
        say "  focus    on - until Freebuff quits (pid $pid)"
      else
        say "  focus    ended with Freebuff - ads are back on the next launch"
        say "           run: $(cmdname) unfocus   (to restore it now)"
      fi
      ;;
    *)
      ends="$(session_ends || true)"
      case "$ends" in
        ''|*[!0-9]*) say "  focus    on - until you run: $(cmdname) unfocus" ; return 0 ;;
      esac
      now="$(date +%s)"
      if [ "$now" -lt "$ends" ]; then
        say "  focus    on until $(clock_at "$ends") ($(( (ends - now + 59) / 60 )) min left)"
      else
        say "  focus    deadline passed at $(clock_at "$ends") - ads are back on the next launch"
        say "           run: $(cmdname) unfocus   (to restore it now)"
      fi
      ;;
  esac
}

# The copy of this tool a detached watcher can execute: the file on disk, or the
# installed one when this run came through curl and has no file behind it.
self_path() {
  if [ "$HAVE_LOCAL" = "1" ] && [ -f "${0:-}" ]; then printf '%s' "$0"; return 0; fi
  [ -f "$INSTALLED_SELF" ] && { printf '%s' "$INSTALLED_SELF"; return 0; }
  return 1
}

# What the file looked like when the patch was written: its length and its mtime.
# The watcher writes only while the file still matches, so an update or a fresh
# install between the patch and the deadline makes it stand down rather than
# overwrite whatever is there now.
file_stamp() {
  size="$(wc -c < "$1" 2>/dev/null | tr -d ' ')" || return 1
  [ -n "$size" ] || return 1
  printf '%s:%s' "$size" "$(file_mtime "$1" || printf '0')"
}

# The newest process running this orchestrator, if any. The same suffix test
# `orchestrator_pids` uses, against the file rather than the bundle, so the
# watcher works out of any app location `--app` was given.
newest_pid_for() {
  want="$1"; best=""; best_start=""
  command -v pgrep >/dev/null 2>&1 || return 0
  for cand in $(pgrep -f "$want" 2>/dev/null); do
    cmd="$(ps -p "$cand" -o command= 2>/dev/null | sed 's/[[:space:]]*$//')"
    case "$cmd" in *"$want") ;; *) continue ;; esac
    s="$(proc_start_epoch "$cand")" || continue
    if [ -z "$best_start" ] || [ "$s" -gt "$best_start" ]; then best="$cand"; best_start="$s"; fi
  done
  [ -n "$best" ] && printf '%s' "$best"
}

# Ask a running watcher to stop and give it a moment to be gone. `unfocus` and a
# second `focus` both call this: two watchers on one session would race to restore
# the same file. The pid is looked up two ways because the watcher records its own
# - there is a moment right after `focus` returns in which the file does not carry
# it yet, and a second `focus` in that moment must not leave the first one alive.
stop_watcher() {
  victims=""
  wpid="$(session_get watcher || true)"
  case "$wpid" in
    ''|*[!0-9]*) ;;
    *) kill -0 "$wpid" 2>/dev/null && victims="$wpid" ;;
  esac
  token="$(session_get run || true)"
  if [ -n "$token" ] && command -v pgrep >/dev/null 2>&1; then
    for cand in $(pgrep -f "watch-run $token" 2>/dev/null); do
      [ "$cand" = "$$" ] && continue
      case " $victims " in *" $cand "*) ;; *) victims="$victims $cand" ;; esac
    done
  fi
  [ -n "$victims" ] || return 0
  for cand in $victims; do kill "$cand" 2>/dev/null || true; done
  waited=0
  while [ "$waited" -lt 3 ]; do
    alive=""
    for cand in $victims; do kill -0 "$cand" 2>/dev/null && alive=1; done
    [ -z "$alive" ] && break
    sleep 1 2>/dev/null || true
    waited=$(( waited + 1 ))
  done
  return 0
}

# One detached process per timed or session focus. `setsid` where it exists, so a
# closed terminal cannot take it down; `nohup` where it does not (macOS ships no
# setsid). The watcher records its own pid - `$!` may name the setsid wrapper,
# which can be gone by the time anything looks.
start_watcher() {
  self="$(self_path)" || return 1
  log="$(session_file).log"
  set -- __watch \
    --app "${app:-}" \
    --backup-dir "$BACKUP_DIR" \
    --session-dir "$SESSION_DIR" \
    --watch-run "$RUN" \
    --watch-target "$TARGET" \
    --watch-backup "$BACKUP" \
    --watch-stamp "$STAMP" \
    --watch-mode "$MODE" \
    --watch-pid "$PID" \
    --watch-ends "$ENDS" \
    --interval "$INTERVAL"
  if command -v setsid >/dev/null 2>&1; then
    setsid sh "$self" "$@" >>"$log" 2>&1 </dev/null &
  else
    nohup sh "$self" "$@" >>"$log" 2>&1 </dev/null &
  fi
  return 0
}

# The watcher. Started by `focus`, never typed: it waits for the one thing that
# ends this focus, puts the pristine file back, and leaves. It logs to
# session.log beside the session file, one line per decision.
cmd_watch() {
  [ -n "$WATCH_RUN" ] || exit 0
  [ -n "$WATCH_TARGET" ] && [ -f "$WATCH_TARGET" ] || exit 0
  log="$(session_file).log"
  watch_log() { printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >>"$log"; }

  # Own the session. A watcher whose session was already replaced exits here
  # rather than watching for a run nobody is waiting on.
  session_set watcher "$$" "$WATCH_RUN" || exit 0
  watch_log "watching $WATCH_MODE${WATCH_PID:+ pid $WATCH_PID} - $WATCH_TARGET"

  while :; do
    if [ "$(session_get run || true)" != "$WATCH_RUN" ]; then
      watch_log 'standing down: the session was cleared or replaced'
      exit 0
    fi

    if [ "$WATCH_MODE" = "session" ]; then
      if [ -z "$WATCH_PID" ]; then
        WATCH_PID="$(newest_pid_for "$WATCH_TARGET")"
        if [ -n "$WATCH_PID" ]; then
          session_set pid "$WATCH_PID" "$WATCH_RUN" || true
          watch_log "Freebuff opened, pid $WATCH_PID"
        fi
      elif ! kill -0 "$WATCH_PID" 2>/dev/null; then
        finish_watch 'Freebuff quit'; exit 0
      fi
    else
      case "$WATCH_ENDS" in
        ''|*[!0-9]*) : ;;
        *) if [ "$(date +%s)" -ge "$WATCH_ENDS" ]; then finish_watch 'the deadline passed'; exit 0; fi ;;
      esac
    fi

    sleep "$INTERVAL"
  done
}

# Put the pristine file back, but only if it is still the file the patch wrote.
# Anything else means someone has already changed it, and silence is the only
# honest answer to that.
finish_watch() {
  reason="$1"
  log="$(session_file).log"
  now="$(date '+%Y-%m-%d %H:%M:%S')"
  if [ "$(file_stamp "$WATCH_TARGET" || true)" != "$WATCH_STAMP" ]; then
    printf '%s %s - left the file alone: it changed after the patch\n' "$now" "$reason" >>"$log"
  elif cp "$WATCH_BACKUP" "$WATCH_TARGET" 2>/dev/null; then
    printf '%s %s - restored %s\n' "$now" "$reason" "$WATCH_TARGET" >>"$log"
  else
    printf '%s %s - could not restore %s (run: unfocus)\n' "$now" "$reason" "$WATCH_TARGET" >>"$log"
  fi
  if [ "$(session_get run || true)" = "$WATCH_RUN" ]; then rm -f "$(session_file)"; fi
}

# When that process started, as an epoch second. Elapsed time is the only thing
# ps gives portably, so the start is now minus it. ps reports it in whole
# seconds, which is a second of slop either way, so the comparison that uses this
# allows for exactly that much and no more - see the pass condition below.
proc_start_epoch() {
  et="$(ps -p "$1" -o etime= 2>/dev/null | tr -d '[:space:]')"
  [ -n "$et" ] || return 1
  days=0
  case "$et" in *-*) days="${et%%-*}"; et="${et#*-}" ;; esac
  h=0; m=0; s=0
  case "$et" in
    *:*:*) h="${et%%:*}"; rest="${et#*:}"; m="${rest%%:*}"; s="${rest#*:}" ;;
    *:*)   m="${et%%:*}"; s="${et#*:}" ;;
    *)     s="$et" ;;
  esac
  case "$days$h$m$s" in *[!0-9]*) return 1 ;; esac
  printf '%s' "$(( $(date +%s) - (days * 86400 + h * 3600 + m * 60 + s) ))"
}

# The readable form of the same thing, for the report only. Never compared.
proc_started_at() {
  ps -p "$1" -o lstart= 2>/dev/null | tr -s ' ' | sed 's/^ //;s/ $//'
}

# The patch time, as an epoch second. BSD stat first (macOS), GNU second, so the
# same helper answers on the machine this patches and in the test sandbox.
file_mtime() {
  m="$(stat -f '%m' "$1" 2>/dev/null)"
  case "$m" in ''|*[!0-9]*) m="$(stat -c '%Y' "$1" 2>/dev/null)" ;; esac
  case "$m" in ''|*[!0-9]*) return 1 ;; esac
  printf '%s' "$m"
}

# "18s after the patch", "4m before the patch" - how the two times differ, in
# words, for the report. Never for the decision.
span_words() {
  secs="$1"; when="after"
  if [ "$secs" -lt 0 ]; then secs=$(( 0 - secs )); when="before"; fi
  if [ "$secs" -lt 90 ]; then printf '%ss %s the patch' "$secs" "$when"
  else printf '%sm %s the patch' "$(( secs / 60 ))" "$when"; fi
}

# The whole line about the two times. A delta inside the last two seconds is
# reported as what it is - as close as the clock here resolves - rather than as
# "1s before the patch", which would read as a contradiction next to a pass.
clock_words() {
  delta="$1"
  if [ "$delta" -lt -2 ]; then
    printf 'that is %s, so it has not been relaunched since' "$(span_words "$delta")"
  elif [ "$delta" -le 1 ]; then
    printf 'that is within a second of the patch, as close as this clock resolves'
  else
    printf 'that is %s' "$(span_words "$delta")"
  fi
}

# The ad runtime this tool patches, as "auction 17 · gravity 4". Empty when none
# of those names appears at all - the one way this build can be said to have no
# ad code left for the patch to block. Read-only.
ad_code_line() {
  engine probes "$1" "$DEEP" 2>/dev/null | awk -F'|' '
    $1 != "PROBE" { next }
    $2 == "auction" || $2 == "displayAd" || $2 == "gravity" ||
    $2 == "sponsor" || $2 == "track/click" {
      if ($3 > 0) { printf "%s%s %s", sep, $2, $3; sep = " · " }
    }'
}

#
# The patch engine.
#
# Perl does the byte-level work: the bundle is one 9 MB line, so the match and
# replace happen in a single pass with the file read whole. The shell passes a
# mode (check|apply) and reads back a report. Every patch is counted before it
# is touched - a mismatch is a refusal, never a guess.
#
engine() {
  mode="$1"; target="$2"; deep="$3"
  prog="$(mktemp "${TMPDIR:-/tmp}/fbd-engine.XXXXXX")" || die "could not create a temp file"
  cat > "$prog" <<'FBD_PERL'
use strict;
use warnings;

my $mode   = shift(@ARGV) // 'check';
my $target = shift(@ARGV) // '';
my $deep   = shift(@ARGV) // '1';
die "no target file\n" unless $target ne '' && -f $target;

# Each patch carries an ordered list of strategies.
#
# The first is the exact literal this tool was verified against. The second is a
# relaxation, so a Freebuff release that renames a function but keeps the shape
# does not brick the tool. A relaxation only counts as a match when it hits the
# expected number of times *and* every hit has ad code beside it, so a decoy
# `if (somethingTest...(process.env))` elsewhere in a 9 MB bundle is never
# mistaken for the ad render path. When nothing matches exactly, the tool still
# refuses - and points at `scan`, which prints what this build actually has.
#
# `layer` separates the render patches from the request choke-points so
# --display-only can drop the latter.
my $AD_NEAR = qr/(?:displayAd|auction|adRequest|adsRequest|gravity|sponsor|track\/click|adServer|adUnit|campaign|\bads?\b)/i;

my @patches = (
  {
    id     => 'render',
    layer  => 'display',
    # One render gate, wherever it lives: 0.0.155 had two (`displayAd` +
    # `auction`), 0.0.164 had one. 0.0.192 kept one but widened its condition to
    # `localAgenticTestCampaign(process.env) || stagingAgenticTestCampaign(process.env)`,
    # so the 0.0.164 literal stopped matching anywhere in the bundle and the tool
    # refused rather than guessed. Both forms are carried - the current one
    # first, the 0.0.164 one second - and both are unique in the builds they were
    # taken from. The other `localAgenticTestCampaign(` calls in 0.0.192 are not
    # `if` conditions on it, so they cannot be hit by either literal.
    what   => 'force the ad auction to return no ads',
    expect => 1,
    tries  => [
      {
        name => 'literal',
        find => qr/\Qif (localAgenticTestCampaign(process.env) || stagingAgenticTestCampaign(process.env))\E/,
        repl => 'if (true/*FBD-ADS-OFF:render*/)',
      },
      {
        name => 'literal-prior',
        find => qr/\Qif (localAgenticTestCampaign(process.env))\E/,
        repl => 'if (true/*FBD-ADS-OFF:render*/)',
      },
      {
        name => 'relaxed',
        find => qr/\bif\s*\(\s*[A-Za-z_\$][\w\$]*Test[A-Za-z_\$]*\s*\(\s*process\.env\s*\)\s*(?:\|\|\s*[A-Za-z_\$][\w\$]*Test[A-Za-z_\$]*\s*\(\s*process\.env\s*\)\s*)*\)/,
        near => $AD_NEAR,
        repl => 'if (true/*FBD-ADS-OFF:render*/)',
      },
    ],
  },
  # There is deliberately no `post` anchor any more, and it must not come back
  # without a reason. The 0.0.155 tool had one, for an ad helper that no longer
  # exists: in 0.0.164 `async post(...)` matches the ad break-event *telemetry*
  # poster and the logs shipper that posts to ${API_HOST}/api/logs. Patching the
  # latter would break Freebuff's own logging and block no ads, and a literal
  # that keeps matching two unrelated helpers is exactly what this tool must not
  # aim at. The `request` anchor below already stops the ad API being reached.
  {
    id     => 'request',
    layer  => 'request',
    what   => 'stop the ad client from reaching the ad API',
    expect => 1,
    tries  => [
      {
        name => 'literal',
        # Re-anchored against 0.0.164, where this is unique. The second argument
        # is matched name-agnostically because it is a minifier-supplied local
        # (`path27` in the build this was verified against) and will be renamed
        # by any future build; the shape around it will not. The other six
        # `async request(` definitions in 0.0.164 belong to a proxy, the sites
        # client and the config clients, and none of them has this signature.
        find => qr/async request\(method, [A-Za-z_\$][\w\$]*, payload, timeoutMs = REQUEST_TIMEOUT_MS\) \{/,
        repl => 'async request(method, path, payload, timeoutMs = REQUEST_TIMEOUT_MS) { return { ok: !1, status: 0, message: "" }; /*FBD-ADS-OFF:request*/',
      },
      {
        name => 'relaxed',
        find => qr/(?<![.\w\$])(?:(?:async|static)\s+)*request\s*\([^)]*\)\s*\{/,
        near => $AD_NEAR,
        repl => 'async request(method, path, payload, timeoutMs = REQUEST_TIMEOUT_MS) { return { ok: !1, status: 0, message: "" }; /*FBD-ADS-OFF:request*/',
      },
    ],
  },
);

# ------------------------------------------------------------------ matching

# Every position a pattern matches, as [offset, length].
sub find_hits {
  my ($src, $find) = @_;
  my @hits;
  while ($src =~ /$find/g) {
    push @hits, [ $-[0], $+[0] - $-[0] ];
  }
  return @hits;
}

# A probe is a substring a person greps for by hand, matched case-insensitively:
# a case-sensitive `agenticTestCampaign` misses `localAgenticTestCampaign`, which
# reads as "the ad runtime is gone" when it is right there.
sub probe_hits {
  my ($src, $probe) = @_;
  return find_hits($src, qr/\Q$probe\E/i);
}

# A relaxation has to be corroborated: ad code within 320 bytes of the hit.
# Literals have no `near` and are trusted as they always were.
sub near_ok {
  my ($src, $hit, $near) = @_;
  return 1 unless defined $near;
  my $from = $hit->[0] - 320;
  $from = 0 if $from < 0;
  return substr($src, $from, $hit->[1] + 640) =~ $near ? 1 : 0;
}

sub window {
  my ($src, $hit, $span) = @_;
  $span = 140 unless defined $span;
  my $from = $hit->[0] - $span;
  $from = 0 if $from < 0;
  my $chunk = substr($src, $from, $hit->[1] + 2 * $span);
  $chunk =~ s/\s+/ /g;
  $chunk =~ s/^ //;
  $chunk =~ s/ $//;
  return $chunk;
}

# The first strategy this source can be patched with, the counts seen, and how
# many hits were ad-adjacent.
sub evaluate {
  my ($src, $p) = @_;
  my @notes;
  my $hits = 0;

  for my $t (@{ $p->{tries} }) {
    my @h = find_hits($src, $t->{find});
    next unless @h;
    my $n    = scalar @h;
    my $near = scalar grep { near_ok($src, $_, $t->{near}) } @h;
    $hits = $n if $n > $hits;
    # A strategy with no `near` is trusted as written, so an adjacency count for
    # it would be vacuous - "6 beside ad code" implies a corroboration that
    # never ran. Say which it is.
    push @notes,
      defined $t->{near}
      ? sprintf('%s: %d match(es), %d beside ad code', $t->{name}, $n, $near)
      : sprintf('%s: %d match(es), trusted as written', $t->{name}, $n);
    next unless $n == $p->{expect} && $near == $n;
    # The first usable strategy wins, and the rest are not even run: on a 9 MB
    # file the literal is the common case, and scanning it once beats scanning
    # every relaxation looking for a better answer that does not exist.
    return ($t, \@notes, $hits);
  }

  return (undef, \@notes, $hits);
}

# --------------------------------------------------------------- scan report

my @PROBES = (
  'displayAd', 'auction', 'agenticTestCampaign', 'testCampaign', 'process.env',
  'async post(', 'async request(', 'gravity', 'sponsor', 'track/click', 'NODE_ENV',
);

# A read-only description of what this build actually contains. This is the
# payload for a re-anchor: if a Freebuff update moves an anchor, `scan` shows
# every candidate site and its surroundings, and nothing is written.
sub run_scan {
  my ($src, $target, $deep) = @_;
  my @o;

  push @o, '== environment ==';
  push @o, "  target   $target";
  push @o, '  bytes    ' . length($src);
  push @o, "  perl     $]";
  push @o, '';

  for my $p (@patches) {
    my $skip   = ($p->{layer} eq 'request' && $deep ne '1') ? 1 : 0;
    my $marker = "FBD-ADS-OFF:$p->{id}";
    my $n      = () = $src =~ /\Q$marker\E/g;

    push @o, sprintf('== %s == %d needed, %d marker(s) already in place', $p->{id}, $p->{expect}, $n);
    push @o, "   $p->{what}";

    if ($skip) {
      push @o, '   skipped: --display-only';
      push @o, '';
      next;
    }

    for my $t (@{ $p->{tries} }) {
      my @h    = find_hits($src, $t->{find});
      my $c    = scalar @h;
      my $near = scalar grep { near_ok($src, $_, $t->{near}) } @h;
      my $uses = ($c == $p->{expect} && $near == $c) ? '   <- usable' : '';

      push @o,
        sprintf(
          defined $t->{near}
          ? '   %-8s %d match(es), %d beside ad code%s'
          : '   %-8s %d match(es), trusted as written%s',
          $t->{name}, $c, (defined $t->{near} ? $near : ()), $uses);

      my $shown = 0;
      for my $h (@h) {
        last if $shown >= 3;
        $shown++;
        push @o, "     [$shown] " . window($src, $h);
      }
    }

    push @o, '';
  }

  push @o, '== probes == (case-insensitive)';
  for my $probe (@PROBES) {
    my @h = probe_hits($src, $probe);
    push @o, sprintf('   %-20s %d', $probe, scalar @h);
    my $shown = 0;
    for my $h (@h) {
      last if $shown >= 2;
      $shown++;
      push @o, "     [$shown] " . window($src, $h, 90);
    }
  }

  return join("\n", @o) . "\n";
}

open(my $in, '<', $target) or die "cannot read $target: $!\n";
binmode $in;
local $/;
my $src = <$in>;
close $in;

if ($mode eq 'scan') {
  print run_scan($src, $target, $deep);
  exit 0;
}

# The same probe counts without the prose. `scan` and the relaunch check both
# want them; only one of those is for a person to read.
if ($mode eq 'probes') {
  for my $probe (@PROBES) {
    my @h = probe_hits($src, $probe);
    printf "PROBE|%s|%d\n", $probe, scalar @h;
  }
  exit 0;
}

my $original = $src;
my @rows;

for my $p (@patches) {
  my $id     = $p->{id};
  my $marker = "FBD-ADS-OFF:$id";
  my $skip   = ($p->{layer} eq 'request' && $deep ne '1') ? 1 : 0;

  my $markers = () = $src =~ /\Q$marker\E/g;
  my $state;
  my $via     = '-';
  my $anchors = 0;
  my @notes   = ();

  if ($skip) {
    $state = 'skipped';
  } elsif ($markers == $p->{expect}) {
    $state = 'applied';
  } elsif ($markers > 0) {
    $state = 'broken';
  } else {
    my ($usable, $notes_ref, $hits) = evaluate($src, $p);
    @notes = @$notes_ref;

    if ($usable) {
      $via     = $usable->{name};
      $anchors = $p->{expect};
      $state   = 'ready';

      if ($mode eq 'apply') {
        my $find = $usable->{find};
        my $repl = $usable->{repl};
        my $n = ($src =~ s/$find/$repl/g);
        if ($n == $p->{expect}) {
          $state   = 'applied';
          $markers = $p->{expect};
          $anchors = 0;
        } else {
          $state = 'failed';
        }
      }
    } else {
      # Nothing usable. A hit count that is merely wrong is ambiguous (the
      # shape is there, the count is not); no hits at all is unknown.
      $state   = $hits ? 'ambiguous' : 'unknown';
      $anchors = scalar find_hits($src, $p->{tries}[0]{find});
    }
  }

  push @rows, {
    id => $id, what => $p->{what}, state => $state, via => $via,
    anchors => $anchors, markers => $markers, expect => $p->{expect},
    # Why it is not ok, carried out to the shell so a refusal can explain
    # itself: "render ambiguous" alone is not a report anyone can act on.
    notes => join('; ', @notes),
  };
}

my $failed = scalar grep { $_->{state} =~ /^(broken|unknown|ambiguous|failed)$/ } @rows;
my $changed = ($src ne $original) ? 1 : 0;

if ($mode eq 'apply' && $changed && !$failed) {
  my @st = stat($target);
  my $perm = $st[2] & 07777;
  my $tmp = "$target.fbd-new";
  open(my $out, '>', $tmp) or die "cannot write $tmp: $!\n";
  binmode $out;
  print $out $src;
  close $out;
  chmod $perm, $tmp;
  rename($tmp, $target) or die "cannot replace $target: $!\n";
}

for my $r (@rows) {
  printf "PATCH|%s|%s|%d|%d|%d|%s|%s|%s\n",
    $r->{id}, $r->{state}, $r->{anchors}, $r->{markers}, $r->{expect},
    $r->{via}, $r->{what}, $r->{notes};
}
printf "WRITTEN|%d\n", ($mode eq 'apply' && $changed && !$failed) ? 1 : 0;
print $failed ? "RESULT|fail\n" : "RESULT|ok\n";
exit($failed ? 3 : 0);
FBD_PERL
  perl "$prog" "$mode" "$target" "$deep"
  code=$?
  rm -f "$prog"
  return $code
}

verdict_of() {
  printf '%s\n' "$1" | sed -n 's/^RESULT|//p' | tail -n 1
}

render_report() {
  printf '%s\n' "$1" | while IFS='|' read -r kind id state anchors markers expect via what notes; do
    [ "$kind" = "PATCH" ] || continue
    case "$state" in
      applied)   mark="${GREEN}applied${OFF}" ;;
      ready)     mark="${YELLOW}ready${OFF}" ;;
      skipped)   mark="${DIM}skipped${OFF}" ;;
      failed)    mark="${RED}failed${OFF}" ;;
      broken)    mark="${RED}broken${OFF}" ;;
      ambiguous) mark="${RED}ambiguous${OFF}" ;;
      unknown)   mark="${RED}not found${OFF}" ;;
      *)         mark="${RED}${state}${OFF}" ;;
    esac
    if [ "$via" = "relaxed" ]; then
      mark="$mark ${DIM}(via relaxed match)${OFF}"
    fi
    printf '  %-9s %s\n' "$id" "$mark"

    # The counts, when the anchor is not simply applied. This is the line that
    # turns "ambiguous" into something a reader can act on without running scan.
    case "$state" in
      ambiguous|unknown|broken|failed)
        [ -n "${notes:-}" ] && printf '            %s%s%s\n' "$DIM" "$notes" "$OFF"
        ;;
    esac
  done
}

all_applied() {
  # $1 report. True when nothing is left to do and nothing is wrong.
  [ "$(verdict_of "$1")" = "ok" ] || return 1
  printf '%s\n' "$1" | awk -F'|' '$1=="PATCH" && $3=="ready" { n++ } END { exit (n>0) }'
}

# Everything this tool can do, at the one moment a reader cares: right after an
# install that found nothing to write. Printed by install only - `status` stays a
# report and `help` stays the long form.
next_steps() {
  say "  ${B}What this tool can do${OFF}"
  say "  status        what is applied, and any focus - changes nothing"
  say "  focus         quiet until you run unfocus"
  say "  focus 25m     quiet until a deadline: 25m, 90m, 2h, 45s"
  say "  focus session quiet until Freebuff quits"
  say "  unfocus       end it now and bring the ads back"
  say "  verify        wait for a relaunch, then check what it loaded"
  say "  scan          every anchor this build contains - read-only"
  say "  revert        restore the pristine backup"
  say "  doctor        environment report"
  say "  diagnose      find out which half of the window stage stops Freebuff"
  say "  update        fetch the newest tool, replace it, then patch again"
  say "  uninstall     remove the command; the patch stays"
  say "  help          every command and option"
  say ""
  # Once the command exists, name it: that is the whole point of installing it.
  if [ -x "$BIN_DIR/$COMMAND_NAME" ]; then
    say "  Run them as:  $COMMAND_NAME <command>"
    if ! path_has_bin; then
      say "  ${DIM}($BIN_DIR is not on PATH in this shell - open a new terminal)${OFF}"
    fi
  else
    say "  Run them as:  $(cmdname) <command>"
    if [ "${HAVE_LOCAL:-0}" != "1" ]; then
      say "  No local copy (this run came through curl)? Install the command once:"
      say "    curl -fsSL $ORIGIN/downloads/freebuff-focus-desktop.sh | sh"
    fi
  fi
}

writable() {
  probe="$1.fbd-probe"
  if ( : > "$probe" ) 2>/dev/null; then rm -f "$probe"; return 0; fi
  return 1
}

permission_help() {
  hr
  say "${B}macOS is blocking writes into the app bundle.${OFF}"
  say ""
  say "  System Settings -> Privacy & Security -> App Management"
  say "  switch ON the app you are running this from (Terminal, iTerm, VS Code…),"
  say "  then ${B}quit and reopen that app${OFF} and run this again."
  say ""
  say "  This is macOS's own guard on app bundles. The tool never asks for a"
  say "  password and never uses sudo."
  hr
}

# ------------------------------------------------------------------ commands

cmd_version() {
  say "freebuff-focus-desktop $VERSION"
  say "$ORIGIN"
}

cmd_help() {
  say "${B}Freebuff Focus for Desktop${OFF} $VERSION"
  say "Blocks the ads Freebuff Desktop renders from its bundled orchestrator."
  say ""
  say "${B}usage${OFF}"
  say "  $(cmdname) [command] [options]"
  say ""
  say "${B}commands${OFF}"
  say "  install   patch the app (default; backs up first, then restarts it)"
  say "  focus     quiet until you run unfocus (no timer, no watcher)"
  say "  focus 25m quiet until a deadline: 25m, 90m, 2h, 45s"
  say "  focus session  quiet until Freebuff quits"
  say "  unfocus   end it now: restore the pristine backup"
  say "  status    report what is applied, and any focus - changes nothing"
  say "  verify    wait for Freebuff to be relaunched, then check what it loaded"
  say "  scan      show every anchor this build has - changes nothing"
  say "  revert    restore the pristine backup"
  say "  doctor    environment report"
  say "  diagnose  find out which half of the window stage stops Freebuff"
  say "  setup     install the tool and the $COMMAND_NAME command (piped runs do this)"
  say "  update    fetch the latest tool, replace this copy, then patch again"
  say "  uninstall  remove the command and the installed copy; the patch stays"
  say "  version   print the tool version"
  say ""
  say "${B}options${OFF}"
  say "  --app PATH         the Freebuff.app to patch (default: /Applications)"
  say "  --display-only     skip the ad-API anchor (leave the render gate only)"
  say "  --dry-run          report only, write nothing"
  say "  --backup-dir PATH  where the pristine copy lives"
  say "  --resign           ad-hoc re-sign the bundle after patching"
  say "  --no-restart       leave the app alone; you quit and reopen it - and skip"
  say "                     the launch check, which needs to start it"
  say "  --restart          quit and relaunch even if the app was closed"
  say "  --session-dir PATH where a focus session is recorded"
  say "  --no-wait          verify: report now instead of waiting for the relaunch"
  say "  --timeout SECONDS  how long verify waits (default 300)"
  say "  --add-path         setup: append ${BIN_DIR} to your shell rc"
  say "  --force            update: reinstall even when the version matches"
  say ""
  say "A focus has three modes, and only what ends it differs:"
  say "  focus          nothing but ${B}unfocus${OFF}. Closing and reopening Freebuff"
  say "                 keeps the ads off - the patched file is still on disk."
  say "  focus 25m      a deadline. A watcher restores the original file when it"
  say "                 passes, so the next start of Freebuff has ads again. A"
  say "                 window that is already open keeps the code it started with"
  say "                 until it restarts - nothing here restarts it for you."
  say "  focus session  quitting Freebuff. The watcher restores the file as the"
  say "                 app exits, so reopening it later shows ads."
  say ""
  say "The watcher is one small ${B}sh${OFF} process per timed or session focus - the"
  say "only thing this tool leaves running. It writes only while the file is still"
  say "the one the patch wrote, so a Freebuff update in the meantime makes it stand"
  say "down instead of overwriting. ${B}unfocus${OFF} stops it."
  say ""
  say "A patch on disk is not the same as a patch in effect: the orchestrator is"
  say "read once at launch. ${B}verify${OFF} waits for the relaunch and reports the"
  say "two times that decide it - when the patch was written and when the process"
  say "running now started. ${B}install${OFF} does that for you whenever Freebuff is"
  say "open. Ctrl-C stops the wait; nothing it does writes to the app."
  say ""
  say "After any Freebuff update, run ${B}install${OFF} again - an update replaces"
  say "the whole Resources folder and the patch goes with it."
  say ""
  say "Each anchor has a literal form and a relaxed one. The relaxed form is only"
  say "used when it is found the expected number of times ${B}and${OFF} ad code sits"
  say "beside it, and a write is undone if the check afterwards disagrees. If a"
  say "patch reports ${B}not found${OFF}, ${B}scan${OFF} lists what this build does have."
}

# ------------------------------------------------------------- shell patch
# The window you actually look at is not the local UI. 0.0.19x opens
# freebuff.com inside Electron, in its own session (app.asar ->
# electron/hosted-workspace.cjs), and that page fetches its ads from the site.
# Nothing in orchestrator.js can reach them. This stage rewrites app.asar twice
# over: the hosted session cancels the ad API before a card can be fetched, and
# the page's preload hides the cards that were already in the document.
#
# app.asar is rewritten by its own bundled bun - no npm, no asar package, no
# network. Only electron/hosted-workspace.cjs and electron/hosted-preload.cjs
# change; every other entry is copied byte for byte and the asar integrity
# hashes are recomputed.

# Only a label on the engine's first line now. The cache is validated by
# comparing the generated bytes, so this does not have to be bumped when the
# engine changes - and forgetting to bump it can no longer publish the old one.
SHELL_JS_TAG='v5'

shell_js_path() {
  mkdir -p "$SESSION_DIR" 2>/dev/null || return 1
  js="$SESSION_DIR/shell-adblock.js"
  # Reuse is decided by content, not by the tag. The tag used to be the whole
  # test, and 1.9.9 shipped a changed engine without bumping it: machines that
  # had run an earlier version kept the old writer forever, so the asar header
  # fix never reached them and every patched build failed to start. Generating
  # beside the cache and moving it into place also means a half-written file can
  # never be read as a complete engine.
  new="$js.new.$$"
  {
  printf '// shell-adblock %s\n' "$SHELL_JS_TAG"
  cat <<'FBD_SHELL_JS'
'use strict';
const fs = require('fs');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const MARK = '/*FBD-ADS-OFF:shell-v2*/';
const PREV = '/*FBD-ADS-OFF:shell*/';
const OLD = 'hostedSession.webRequest.onBeforeRequest(null)';
const PATHS = '/^\\/api\\/(?:ads?(?:\\/|$)|web\\/ads(?:\\/|$)|ad-|sponsored-|google-ads(?:\\/|$)|advertiser|meta\\/ads-|telemetry\\/ad-)/i';
const NEW = 'hostedSession.webRequest.onBeforeRequest((_d,_c)=>{let p=_d.url;try{p=new URL(_d.url).pathname}catch(e){}return _c({cancel:' + PATHS + '.test(p)})})' + MARK;
const PAGE_MARK = '/*FBD-ADS-OFF:dom-v1*/';
const PAGE_ANCHOR = "contextBridge.exposeInMainWorld('freebuffHost'";
// Cancelling the ad API stops cards being fetched, but a card the server already
// put in the document has no request left to cancel. So the page hides ad nodes as
// well, by the attributes the site marks them with. Inline styles rather than a
// <style> element: a CSP style-src would drop the element, never the CSSOM.
const PAGE = [
  // The file ends in a call expression with no semicolon, so a bare IIFE after it
  // would be read as another call of that expression.
  '',
  ';',
  '// ' + PAGE_MARK + ' Hidden before paint and again on every render, because a card',
  '// can arrive inside a response that was already under way.',
  '(function () {',
  '  try {',
  '    var AD = \'[data-gravity-ad],[data-ad-slot],[aria-label*="(Ad)"],[class*="gravity-ad"],[class*="partner-placement"]\';',
  '    function hide(node) { try { node.style.setProperty(\'display\', \'none\', \'important\') } catch (e) {} }',
  '    function sweep() {',
  '      var ads = document.querySelectorAll(AD);',
  '      for (var i = 0; i < ads.length; i++) {',
  '        var node = ads[i];',
  '        // A wrapper that holds nothing but the ad goes too, or it leaves a gap.',
  '        for (var up = 0; up < 3; up++) {',
  '          var parent = node.parentElement;',
  '          if (!parent || parent === document.body || parent === document.documentElement) break;',
  '          if (parent.children.length > 1) break;',
  '          if ((parent.textContent || \'\').trim() !== (node.textContent || \'\').trim()) break;',
  '          node = parent;',
  '        }',
  '        hide(node);',
  '      }',
  '    }',
  '    sweep();',
  '    document.addEventListener(\'DOMContentLoaded\', sweep, { once: true });',
  '    var queued = false;',
  '    new MutationObserver(function () {',
  '      if (queued) return;',
  '      queued = true;',
  '      setTimeout(function () { queued = false; sweep() }, 50);',
  '    }).observe(document, { childList: true, subtree: true });',
  '  } catch (e) {}',
  '})();',
  '',
].join('\n');
function readAsar(p) {
  const buf = fs.readFileSync(p);
  if (buf.length < 16) throw new Error('not an asar');
  const headerSize = buf.readUInt32LE(4);
  const jlen = buf.readUInt32LE(12);
  const header = JSON.parse(buf.slice(16, 16 + jlen).toString('utf8').replace(/\0+$/, '').trimEnd());
  return { buf, header, jlen, base: 8 + headerSize };
}
// What Electron's asar-integrity fuse compares against the hash recorded in
// Info.plist on macOS: SHA256 over the header block, padding included.
function headerHash(buf, jlen) {
  return crypto.createHash('sha256').update(buf.slice(16, 16 + jlen)).digest('hex');
}
function walk(node, prefix, out) {
  for (const name of Object.keys(node.files || {})) {
    const entry = node.files[name];
    const p = prefix ? prefix + '/' + name : name;
    if (entry.files) walk(entry, p, out);
    else out.push({ path: p, entry });
  }
  return out;
}
// The plist key Electron records a hash under. It contains a slash and a dot,
// which PlistBuddy reads as path separators, so the plist is edited through
// plutil's XML form instead of by key path.
const ASAR_KEY = 'Resources/app.asar';
const PLUTIL = process.env.FREEBUFF_FOCUS_PLUTIL || 'plutil';
function plutil(args) {
  const run = spawnSync(PLUTIL, args, { encoding: 'utf8' });
  if (run.error) throw new Error('plutil is not available');
  if (run.status !== 0) throw new Error((run.stderr || 'plutil failed').trim().split('\n')[0]);
  return run.stdout;
}
const plistXml = (file) => plutil(['-convert', 'xml1', '-o', '-', file]);
// Where the recorded hash sits in that XML, and what it says. found:false means
// this build has no asar-integrity fuse at all.
function recordedHash(xml) {
  const at = xml.indexOf('<key>ElectronAsarIntegrity</key>');
  if (at < 0) return { found: false };
  const key = xml.indexOf('<key>' + ASAR_KEY + '</key>', at);
  if (key < 0) return { found: false };
  const hk = xml.indexOf('<key>hash</key>', key);
  if (hk < 0) throw new Error('the asar entry in Info.plist records no hash');
  const start = xml.indexOf('<string>', hk);
  const end = xml.indexOf('</string>', start);
  if (start < 0 || end < 0) throw new Error('the asar hash in Info.plist is not a string');
  return { found: true, value: xml.slice(start + 8, end), start: start + 8, end };
}
// Read the recorded hash ('-' when the build records none), or replace it and
// read back to prove the write landed.
function plistMode(file, value) {
  const xml = plistXml(file);
  const seen = recordedHash(xml);
  if (!seen.found) { console.log('-'); return; }
  if (value === undefined || value === '-') { console.log(seen.value); return; }
  const mode = fs.statSync(file).mode;
  const xmlTmp = file + '.fbd-xml', outTmp = file + '.fbd-new';
  fs.writeFileSync(xmlTmp, xml.slice(0, seen.start) + value + xml.slice(seen.end));
  plutil(['-convert', 'binary1', '-o', outTmp, xmlTmp]);
  fs.chmodSync(outTmp, mode & 0o7777);
  fs.renameSync(outTmp, file);
  fs.rmSync(xmlTmp, { force: true });
  const after = recordedHash(plistXml(file));
  if (!after.found || after.value !== value) throw new Error('the new hash did not stay written');
  console.log('ok');
}
function main(argv) {
  const mode = argv[0], asarPath = argv[1];
  if (mode === 'plist') { plistMode(asarPath, argv[2]); return; }
  const { buf, header, jlen, base } = readAsar(asarPath);
  if (mode === 'hash') { console.log(headerHash(buf, jlen)); return; }
  const files = walk(header, '', []);
  const read = (f) => buf.slice(base + Number(f.entry.offset), base + Number(f.entry.offset) + Number(f.entry.size));
  const shell = files.find((f) => f.path === 'electron/hosted-workspace.cjs');
  if (!shell) throw new Error('hosted-workspace.cjs not found');
  const shellText = read(shell).toString('utf8');
  let shellDone = shellText.includes(MARK);
  // Older builds have no preload beside the window, so an absent file is not a
  // failure: there is simply nothing in the document to hide.
  const page = files.find((f) => f.path === 'electron/hosted-preload.cjs');
  const pageText = page ? read(page).toString('utf8') : null;
  let pageDone = page ? pageText.includes(PAGE_MARK) : true;
  // `diagnose` writes one half of the stage at a time, to find out which half a
  // build refuses. FBD_ONLY makes the other half look done, so it is not written.
  const only = process.env.FBD_ONLY || '';
  if (only === 'request') pageDone = true;
  else if (only === 'render') shellDone = true;
  if (mode === 'check') {
    console.log(JSON.stringify({
      shell: shellDone, page: pageDone, patched: shellDone && pageDone,
      stale: !shellDone && shellText.includes(PREV),
      anchor: shellText.includes(OLD), pageFile: !!page, files: files.length,
    }));
    return;
  }
  if (shellDone && pageDone) { console.log('already patched'); return; }
  const next = new Map();
  if (!shellDone) {
    if (!shellText.includes(OLD)) throw new Error(shellText.includes(PREV) ? 'previous block present' : 'anchor not found');
    next.set(shell, Buffer.from(shellText.replace(OLD, NEW), 'utf8'));
  }
  if (!pageDone) {
    if (!pageText.includes(PAGE_ANCHOR)) throw new Error('the page preload is not what this build ships');
    next.set(page, Buffer.from(pageText + PAGE, 'utf8'));
  }
  for (const [target, body] of next) {
    if (target.entry.integrity) {
      const blockSize = target.entry.integrity.blockSize || 4194304;
      const blocks = [];
      for (let i = 0; i < body.length; i += blockSize) {
        blocks.push(crypto.createHash('sha256').update(body.slice(i, i + blockSize)).digest('hex'));
      }
      target.entry.integrity.hash = crypto.createHash('sha256').update(body).digest('hex');
      target.entry.integrity.blocks = blocks;
    }
    target.entry.size = body.length;
  }
  let offset = 0;
  const parts = [];
  for (const f of files) {
    if (f.entry.unpacked) continue;
    const body = next.get(f) || read(f);
    f.entry.offset = String(offset);
    offset += body.length;
    parts.push(body);
  }
  const json = Buffer.from(JSON.stringify(header), 'utf8');
  const pad = (4 - (json.length % 4)) % 4;
  const newJlen = json.length + pad;
  const head = Buffer.alloc(16);
  head.writeUInt32LE(4, 0);
  head.writeUInt32LE(newJlen + 8, 4);
  head.writeUInt32LE(newJlen + 4, 8);
  // The length field is the JSON's own byte count, padding excluded: Electron
  // reads exactly that many bytes as the header string, and a padded count makes
  // it read the NUL pad as part of the JSON. archive.cc calls that "Failed to
  // parse header" and the bundle does not start.
  head.writeUInt32LE(json.length, 12);
  const out = Buffer.concat([head, json, Buffer.alloc(pad), ...parts]);
  fs.writeFileSync(asarPath + '.fbd-tmp', out);
  fs.renameSync(asarPath + '.fbd-tmp', asarPath);
  console.log(JSON.stringify({ patched: true, shell: !shellDone, page: !pageDone, size: out.length, files: files.length, hash: headerHash(out, json.length) }));
}
main(process.argv.slice(2));
FBD_SHELL_JS
  } >"$new" || { rm -f "$new"; return 1; }
  if [ -f "$js" ] && cmp -s "$new" "$js"; then
    rm -f "$new"
  else
    mv -f "$new" "$js" || { rm -f "$new"; return 1; }
  fi
  printf '%s\n' "$js"
}

# The app ships the only runtime this needs. FREEBUFF_FOCUS_BUN is for tests on
# a machine whose app bundle cannot execute here.
shell_bun() {
  if [ -n "${FREEBUFF_FOCUS_BUN:-}" ] && [ -x "$FREEBUFF_FOCUS_BUN" ]; then
    printf '%s\n' "$FREEBUFF_FOCUS_BUN"
    return 0
  fi
  bun="$1/Contents/Resources/bun/bun"
  [ -x "$bun" ] && printf '%s\n' "$bun"
}

# 0.0.200 ships an asar-integrity fuse: Info.plist records the SHA256 of the
# app.asar header, and Electron refuses to start when the two disagree. Any
# rewrite of app.asar changes that header, so the recorded hash has to follow
# or the app silently stops launching. The key is called "Resources/app.asar",
# and PlistBuddy reads both / and : as path separators, so the plist is edited
# through plutil's XML form by the embedded JS rather than by key path.

# The hash this build records for app.asar: '-' when it records none, a failure
# when the plist could not be read at all.
plist_hash() {
  app="$1"
  [ -f "$app/Contents/Info.plist" ] || { printf -- '-\n'; return 0; }
  bun="$(shell_bun "$app")" || return 1
  js="$(shell_js_path)" || return 1
  "$bun" "$js" plist "$app/Contents/Info.plist" 2>/dev/null || return 1
}

shell_asar_hash() {
  bun="$(shell_bun "$1")" || return 1
  js="$(shell_js_path)" || return 1
  "$bun" "$js" hash "$1/Contents/Resources/app.asar" 2>/dev/null
}

# ok | mismatch | none (this build does not check) | unknown (cannot tell)
# 'unknown' is not 'none': a plist that cannot be read must never be reported as
# a build without the fuse, or an unreadable hash looks like a safe one.
shell_integrity() {
  want="$(plist_hash "$1")" || { printf 'unknown\n'; return 0; }
  [ "$want" = "-" ] && { printf 'none\n'; return 0; }
  got="$(shell_asar_hash "$1")" || { printf 'unknown\n'; return 0; }
  if [ -n "$want" ] && [ "$want" = "$got" ]; then
    printf 'ok\n'
  else
    printf 'mismatch\n'
  fi
}

# ok | updated | none | failed
shell_sync_integrity() {
  app="$1"; plist="$app/Contents/Info.plist"
  want="$(plist_hash "$app")" || { printf 'failed\n'; return 0; }
  [ "$want" = "-" ] && { printf 'none\n'; return 0; }
  got="$(shell_asar_hash "$app")" || { printf 'failed\n'; return 0; }
  [ "$want" = "$got" ] && { printf 'ok\n'; return 0; }
  bun="$(shell_bun "$app")" || { printf 'failed\n'; return 0; }
  js="$(shell_js_path)" || { printf 'failed\n'; return 0; }
  "$bun" "$js" plist "$plist" "$got" >/dev/null 2>&1 \
    || { printf 'failed\n'; return 0; }
  [ "$(plist_hash "$app")" = "$got" ] && printf 'updated\n' || printf 'failed\n'
}

# patched | unpatched | unsupported - never a guess about pixels, only the file.
shell_state() {
  asar="$1/Contents/Resources/app.asar"
  [ -f "$asar" ] || { printf 'unsupported\n'; return 0; }
  bun="$(shell_bun "$1")" || { printf 'unsupported\n'; return 0; }
  js="$(shell_js_path)" || { printf 'unsupported\n'; return 0; }
  out="$("$bun" "$js" check "$asar" 2>/dev/null)" || { printf 'unsupported\n'; return 0; }
  case "$out" in
    *'"shell":true,"page":false'*) printf 'partial\n' ;;
    *'"patched":true'*) printf 'patched\n' ;;
    *'"stale":true'*) printf 'stale\n' ;;
    *'"patched":false'*) printf 'unpatched\n' ;;
    *) printf 'unsupported\n' ;;
  esac
}

shell_apply() {
  app="$1"; version="$2"
  state="$(shell_state "$app")"
  asar="$app/Contents/Resources/app.asar"
  plist="$app/Contents/Info.plist"
  backup="$BACKUP_DIR/app.asar.$version.orig"
  plist_backup="$BACKUP_DIR/Info.plist.$version.orig"
  case "$state" in
    unsupported)
      say "  window   ${DIM}not blocked - this build has no app.asar to rewrite${OFF}"
      return 0 ;;
    stale)
      # An older block is in place and matched too few URLs. Its anchor is gone, so
      # only the pristine backup can be rewritten again.
      if [ ! -f "$backup" ]; then
        warn "app.asar has an older block and no pristine backup to re-apply over"
        return 1
      fi
      cp "$backup" "$asar" 2>/dev/null || { warn "could not rewind app.asar to its backup"; return 1; }
      say "  window   older block found - replacing it" ;;
    patched)
      ok "window   the ad API is already blocked in app.asar" ;;
    partial)
      say "  window   the request block is in place, the page hide is not - adding it" ;;
  esac
  if [ "$state" != "patched" ]; then
    bun="$(shell_bun "$app")"; js="$(shell_js_path)" || return 1
    mkdir -p "$BACKUP_DIR" 2>/dev/null || true
    if [ ! -f "$backup" ]; then
      if ! cp "$asar" "$backup" 2>/dev/null; then
        warn "could not back up app.asar - leaving the window's ads alone"
        return 1
      fi
    fi
    patch_err="$("$bun" "$js" patch "$asar" 2>&1)" && patch_ok=1 || patch_ok=0
    if [ "$patch_ok" = 0 ] || [ "$(shell_state "$app")" != "patched" ]; then
      cp "$backup" "$asar" 2>/dev/null || true
      reason="$(printf '%s\n' "$patch_err" | grep -m1 -E 'Error: |error: ' | sed 's/^Error: //; s/^ *//')"
      warn "could not block the window's ad API - app.asar was put back as it was${reason:+ ($reason)}"
      return 1
    fi
    ok "window   blocked the ad API in app.asar"
    say "  backup   $backup"
  fi
  # Keep Info.plist's copy of the asar hash in step, and keep the original bytes
  # so revert can put back a file that still describes the pristine asar.
  if [ ! -f "$plist_backup" ] && [ -f "$plist" ]; then
    cp "$plist" "$plist_backup" 2>/dev/null || true
  fi
  integrity="$(shell_sync_integrity "$app")"
  case "$integrity" in
    ok|none) : ;;
    updated)
      ok "window   app.asar hash updated in Info.plist"
      say "  backup   $plist_backup" ;;
    *)
      # A block Electron will not load is worse than no block: make the app start.
      cp "$backup" "$asar" 2>/dev/null || true
      if [ -f "$plist_backup" ]; then
        cp "$plist_backup" "$plist" 2>/dev/null || true
      fi
      warn "this build checks app.asar against a hash in Info.plist and the tool could not update it - app.asar was put back as it was"
      return 1 ;;
  esac
}

shell_restore() {
  app="$1"; version="$2"
  asar="$app/Contents/Resources/app.asar"
  plist="$app/Contents/Info.plist"
  backup="$BACKUP_DIR/app.asar.$version.orig"
  plist_backup="$BACKUP_DIR/Info.plist.$version.orig"
  [ -f "$backup" ] || return 0
  [ -f "$asar" ] || return 0
  case "$(shell_state "$app")" in
    patched|stale)
      if cp "$backup" "$asar" 2>/dev/null; then
        ok "restored app.asar from $backup"
        if [ -f "$plist_backup" ]; then
          if cp "$plist_backup" "$plist" 2>/dev/null; then
            ok "restored Info.plist from $plist_backup"
          fi
        fi
        # Older installs never backed up the plist: make it describe this asar.
        shell_sync_integrity "$app" >/dev/null 2>&1 || true
      else
        warn "could not restore app.asar - copy it back by hand: $backup"
      fi ;;
  esac
}

cmd_status() {
  app="$(find_app)" || die "Freebuff Desktop was not found in /Applications or ~/Applications.
  Pass --app /path/to/Freebuff.app if it lives somewhere else."
  target="$app/Contents/Resources/orchestrator/orchestrator.js"
  [ -f "$target" ] || die "no orchestrator.js in $app - is that the Freebuff app?"

  version="$(app_version "$app")"
  say "${B}Freebuff Focus${OFF} - desktop tool $VERSION"
  say "  app      $app"
  say "  freebuff $version (installed)"
  say "  target   $target"
  session_line
  say ""

  report="$(engine check "$target" "$DEEP")"
  render_report "$report"

  window_state="$(shell_state "$app")"
  integrity_state="$(shell_integrity "$app")"
  # A case inside $( ) trips the bash 3.2 that macOS ships as /bin/sh, so the
  # label is chosen first and printed after.
  case "$window_state" in
    patched) window_note="ad API blocked and ad cards hidden (app.asar)" ;;
    partial) window_note="ad API blocked, ad cards not hidden yet - run: $(cmdname) install" ;;
    stale) window_note="older block - run: $(cmdname) install" ;;
    unpatched) window_note="not blocked - run: $(cmdname) install" ;;
    *) window_note="n/a on this build" ;;
  esac
  case "$integrity_state" in
    ok) window_note="$window_note, hash verified" ;;
    mismatch) window_note="$window_note, but Info.plist's asar hash is stale - Freebuff will not start; run: $(cmdname) install" ;;
    unknown) window_note="$window_note, but Info.plist's asar hash could not be read - the app may not start; run: $(cmdname) install" ;;
  esac
  say "  window   $window_note"
  # A start that failed is the one piece of state a file check cannot report,
  # and it is the state that leaves the reader with no app to look at.
  if [ -f "$SESSION_DIR/launch.failed" ] && [ -z "$(orchestrator_pids "$app")" ]; then
    say "  launch   ${YELLOW}the last start of Freebuff failed${OFF}: $(cut -c1-110 "$SESSION_DIR/launch.failed" 2>/dev/null)"
    say "           everything it printed is in $(launch_log)"
  fi

  if [ "$(verdict_of "$report")" = "ok" ]; then
    if all_applied "$report"; then
      say ""
      if [ "$window_state" = "patched" ] && [ "$integrity_state" = "mismatch" ]; then
        say "  ${YELLOW}The block is written, but Info.plist's copy of the app.asar hash is stale.${OFF}"
        say "  macOS builds from 0.0.200 on verify that hash and refuse to start, so"
        say "  Freebuff will not open until it is updated. Run: $(cmdname) install"
        return 0
      elif [ "$window_state" = "patched" ] && [ "$integrity_state" = "unknown" ]; then
        say "  ${YELLOW}The block is written, but the asar hash in Info.plist could not be read.${OFF}"
        say "  A build that verifies it will refuse to start. Run: $(cmdname) install"
        return 0
      elif [ "$window_state" = "patched" ]; then
        say "  ${GREEN}Ads are off.${OFF} Quit Freebuff and reopen it, then check what it loaded:"
      else
        say "  ${YELLOW}The local ad auction is off, but the window is not.${OFF}"
        say "  The desktop window renders freebuff.com, whose ads are served by the"
        say "  site; only the app.asar stage stops those. Run: $(cmdname) install"
      fi
      say "    $(cmdname) verify"
    else
      say ""
      say "  ${YELLOW}Not patched yet.${OFF} Run: $(cmdname) install"
    fi
    return 0
  fi

  say ""
  bad "This orchestrator.js does not match what the tool expects."
  say "  Either it was already modified by another tool, or this Freebuff version"
  say "  changed the file. Nothing was written."
  say ""
  say "  See what this build actually has:  $(cmdname) scan"
  say ""
  if [ -f "$BACKUP_DIR/orchestrator.js.$version.orig" ]; then
    say "  A pristine backup exists. Restore it, then install again:"
    say "    $(cmdname) revert && $(cmdname) install"
  else
    say "  If you patched this by hand before, restore the original file first."
  fi
  return 1
}

cmd_install() {
  app="$(find_app)" || die "Freebuff Desktop was not found in /Applications or ~/Applications.
  Pass --app /path/to/Freebuff.app if it lives somewhere else."
  target="$app/Contents/Resources/orchestrator/orchestrator.js"
  [ -f "$target" ] || die "no orchestrator.js in $app - is that the Freebuff app?"

  version="$(app_version "$app")"

  say "${B}Freebuff Focus${OFF} - desktop tool $VERSION"
  say "  app      $app"
  say "  freebuff $version (installed)"
  say ""

  report="$(engine check "$target" "$DEEP")" || true

  if [ "$(verdict_of "$report")" != "ok" ]; then
    render_report "$report"
    say ""
    bad "Refusing to patch - the file does not match this tool's expectations."
    say "  Nothing was written. Either it was modified by another tool, or this"
    say "  Freebuff version changed the ad code."
    say ""
    say "  See what this build actually has:"
    say "    $(cmdname) scan                        (a local copy)"
    say "    curl -fsSL $ORIGIN/downloads/freebuff-focus-desktop.sh | sh -s scan"
    say "  Read-only either way. The piped one is for when you ran this through"
    say "  curl and have no local copy of the script to point at."
    say ""
    if [ -f "$BACKUP_DIR/orchestrator.js.$version.orig" ]; then
      say "  A pristine backup is on disk:"
      say "    $(cmdname) revert && $(cmdname) install"
      say "    curl -fsSL $ORIGIN/downloads/freebuff-focus-desktop.sh | sh -s revert"
    fi
    return 1
  fi

  if all_applied "$report"; then
    # Nothing to write, so this run is worth only what it reports: which anchors
    # are already in place, whether a session is running, whether the process
    # you are looking at is reading the patched bytes, and what else the tool
    # can do from here. "Nothing to do" alone answered none of that.
    say "  ${GREEN}Already patched.${OFF} Every anchor in this build is already replaced."
    render_report "$report"
    # An install of 1.9.0 over a bundle patched by 1.8.x lands here: the
    # orchestrator is already done, the window stage is not. So does a bundle
    # whose app.asar is blocked but whose Info.plist still records the pristine
    # hash - the state that stops 0.0.200 from starting at all.
    if [ "$(shell_state "$app")" != "patched" ] || [ "$(shell_integrity "$app")" = "mismatch" ]; then
      if shell_apply "$app" "$version"; then
        if [ "$RESIGN" = "1" ] && command -v codesign >/dev/null 2>&1; then
          codesign --force --deep --sign - "$app" 2>/dev/null \
            && ok "re-signed the bundle ad-hoc" \
            || warn "re-sign failed - run: codesign --force --deep --sign - '$app'"
        fi
      fi
      say ""
    fi
    session_line
    if [ ! -f "$(session_file)" ]; then
      say "  focus    none - ads stay off until you revert"
    fi
    say ""

    ensure_starts "$app" "$version" || true
    running="$(orchestrator_pids "$app")"
    if [ -z "$running" ]; then
      say "  ${B}Next: open Freebuff.${OFF} The orchestrator is read once at launch,"
      say "  so the patch takes effect on the next start."
      say "  Then check what it loaded:  $(cmdname) verify"
    elif stale_process "$app" "$target"; then
      if [ "$RESTART" = "never" ]; then
        say "  ${B}Freebuff is running the bytes from before the patch.${OFF}"
        say "  Quit it completely and reopen it - focusing the window is not enough."
        say "  Then check what it loaded:  $(cmdname) verify"
      else
        say "  A process that started before the patch is still running it."
        if restart_app "$app"; then
          say "  restarted Freebuff"
          # A launch that is gone by the next breath is the failure this whole
          # check exists for, and verify only reports on a running app.
          if confirm_started "$app" "$version"; then
            [ "$WAIT" = "1" ] && { verify_running "$app" "$target" || true; }
          fi
        elif rescue_app "$app" "$version"; then
          [ "$WAIT" = "1" ] && { verify_running "$app" "$target" || true; }
        fi
      fi
    else
      say "  ${B}Freebuff is running the patched file.${OFF} Ads are off in that window."
    fi

    say ""
    next_steps
    return 0
  fi

  say "  Would patch:"
  render_report "$report"
  say ""

  if [ "$DRY" = "1" ]; then
    say "  ${DIM}--dry-run: nothing was written.${OFF}"
    return 0
  fi

  if ! writable "$target"; then
    permission_help
    return 1
  fi

  command -v perl >/dev/null 2>&1 || die "perl is required but was not found (it ships with macOS)"
  mkdir -p "$BACKUP_DIR"
  backup="$BACKUP_DIR/orchestrator.js.$version.orig"
  if [ -f "$backup" ]; then
    say "  backup   ${DIM}kept${OFF} $backup"
  else
    if ! cp "$target" "$backup" 2>/dev/null; then
      permission_help
      return 1
    fi
    say "  backup   $backup"
  fi

  say ""
  engine apply "$target" "$DEEP" >/dev/null || {
    bad "the patch did not apply cleanly - the file was left untouched"
    return 1
  }

  after="$(engine check "$target" "$DEEP")" || true

  # A relaxed anchor is an inference, not a literal this tool was verified
  # against, so the write only stands if a fresh count agrees with it. If it
  # does not, the pristine copy goes straight back - a half-patched bundle is
  # the one outcome worth undoing.
  if [ "$(verdict_of "$after")" != "ok" ] || ! all_applied "$after"; then
    render_report "$after"
    say ""
    bad "the patch did not verify after writing - putting the original back"
    if cp "$backup" "$target" 2>/dev/null; then
      ok "restored $target"
    else
      bad "could not restore $target - copy it back by hand: $backup"
    fi
    return 1
  fi

  render_report "$after"
  say ""

  # The local auction is only half the story: the window renders freebuff.com in
  # its own session, so its ads have to be blocked there too. A failure here is
  # reported rather than swallowed: it means the window still shows ads, and on
  # builds that verify app.asar it can also mean the app would not start.
  if shell_apply "$app" "$version"; then
    window_ok=1
  else
    window_ok=0
  fi
  say ""

  if [ "$RESIGN" = "1" ] && command -v codesign >/dev/null 2>&1; then
    if codesign --force --deep --sign - "$app" 2>/dev/null; then
      ok "re-signed the bundle ad-hoc"
    else
      warn "re-sign failed - Freebuff may refuse to launch; run: codesign --force --deep --sign - '$app'"
    fi
  fi

  if [ "$window_ok" = 1 ]; then
    ok "patched Freebuff $version"
  else
    warn "patched the local auction, but the window stage failed - the ads above the composer are still on"
  fi
  hr

  # A fresh write means any recorded session describes the old bytes. The watcher
  # that was waiting on them has to go before it restores the wrong thing, and a
  # session nobody is watching is worse than no session at all.
  if [ -f "$(session_file)" ] && [ "$(session_get stamp || true)" != "$(file_stamp "$target" || true)" ]; then
    stop_watcher
    rm -f "$(session_file)" 2>/dev/null || true
    say "  focus    cleared - the patch was rewritten"
    say ""
  fi

  running="$(orchestrator_pids "$app")"
  if [ "$RESTART" = "never" ]; then
    if [ -n "$running" ]; then
      say "${B}Freebuff is running. Quit it completely (Cmd-Q) and reopen it.${OFF}"
      say "The orchestrator is read once at launch, so the patch only takes effect"
      say "on the next start - focusing the window is not enough."
      say "  Then check what it loaded:  $(cmdname) verify"
    else
      say "${B}Open Freebuff.${OFF} The patch takes effect on the next launch."
      say "  Then check what it loaded:  $(cmdname) verify"
    fi
  elif [ -n "$running" ] || [ "$RESTART" = "always" ]; then
    say "${B}Restarting Freebuff so the patch takes effect.${OFF}"
    say "The orchestrator is read once at launch, so a running app has to be"
    say "restarted - focusing the window is not enough."
    say ""
    if restart_app "$app"; then
      say "  restarted Freebuff"
      # Only when there is a relaunch to wait for. A closed app has nothing to
      # observe, and an unattended install must not sit here for five minutes.
      if [ "$WAIT" = "1" ]; then
        verify_running "$app" "$target" || true
      else
        say "  Then check what it loaded:  $(cmdname) verify"
      fi
    elif rescue_app "$app" "$version"; then
      # It is open, but not necessarily on the bytes that were just written:
      # rescue_app either started it directly or put the window stage back. Both
      # were said where they happened, and there is no relaunch here to wait for.
      say "  Then check what it loaded:  $(cmdname) verify"
    else
      warn "Freebuff is not running. Start it by hand and read the message it prints"
    fi
  elif ensure_starts "$app" "$version"; then
    :  # it opened the app, or put the window stage back and opened it; both were
       # said where they happened.
  else
    say "${B}Open Freebuff.${OFF} The patch takes effect on the next launch."
    say "  If it closes again as it opens, the window stage is what it refuses:"
    say "    $(cmdname) revert      (the bundle goes back to its own bytes)"
    say "  Then check what it loaded:  $(cmdname) verify"
  fi
  say ""
  say "Undo any time: ${B}unfocus${OFF} ends a session."
  say "Back to ads only: $(cmdname) revert"
  say "After a Freebuff update, run ${B}install${OFF} again."
  say "For a newer version of this tool itself: ${B}$(cmdname) update${OFF}"
  say ""
  next_steps
}

# --------------------------------------------------------------- the command

path_has_bin() {
  case ":${PATH:-}:" in *":$BIN_DIR:"*) return 0 ;; esac
  return 1
}

# The rc file the login shell actually reads. zsh is the macOS default and bash
# the Linux one; anything else gets .profile, which every POSIX shell reads.
shell_rc() {
  case "${SHELL:-}" in
    */zsh)  printf '%s' "${ZDOTDIR:-$HOME}/.zshrc" ;;
    */bash) printf '%s' "$HOME/.bashrc" ;;
    *)      printf '%s' "$HOME/.profile" ;;
  esac
}

# Append the bin folder once, behind a marker, so a second run cannot double it.
add_to_path() {
  rc="$(shell_rc)"
  marker='# freebuff-focus PATH'
  grep -qF "$marker" "$rc" 2>/dev/null && return 0
  {
    printf '\n%s\n' "$marker"
    printf 'export PATH="%s:$PATH"\n' "$BIN_DIR"
  } >>"$rc" 2>/dev/null || return 1
  say "  path      added $BIN_DIR to $rc"
  return 0
}

# The version a copy of this tool records. Empty means it is not this tool.
version_of() {
  sed -n 's/^VERSION="\(.*\)"$/\1/p' "$1" 2>/dev/null | head -n 1
}

# True when the first version is strictly newer than the second, dotted numbers
# compared one field at a time. Used to refuse a downgrade: the site is the
# authority on what is current, but it must never hand back something older than
# what is already on disk and call it an update.
version_newer() {
  awk -v a="$1" -v b="$2" 'BEGIN {
    n = split(a, x, "."); m = split(b, y, ".")
    for (i = 1; i <= (n > m ? n : m); i++) {
      if ((x[i] + 0) > (y[i] + 0)) exit 0
      if ((x[i] + 0) < (y[i] + 0)) exit 1
    }
    exit 1
  }'
}

# A launcher is one line plus the name it answers to. Both the long command and
# the short alias get the same launcher, and a file this tool did not write is
# left alone: someone's own `freebuff-focus` command is theirs, not ours.
write_shim() {
  # $1 = the name to write in $BIN_DIR
  name="$1"
  shim="$BIN_DIR/$name"
  if [ -e "$shim" ] && ! grep -qF "# Freebuff Focus launcher" "$shim" 2>/dev/null; then
    warn "$shim already exists and was not written by this tool - left alone"
    return 1
  fi
  printf '#!/bin/sh\n# Freebuff Focus launcher - written by `%s setup`.\nexec sh "%s" "$@"\n' \
    "$COMMAND_NAME" "$INSTALLED_SELF" >"$shim" 2>/dev/null || return 1
  chmod 755 "$shim" 2>/dev/null || return 1
  return 0
}

# Install the tool and the command that runs it. The first `curl | sh` does this,
# so the reader gets `freebuff-focusmode status` instead of a file they have to
# name and a path they have to remember.
cmd_setup() {
  mkdir -p "$INSTALL_DIR" "$BIN_DIR" 2>/dev/null || die "cannot create $INSTALL_DIR or $BIN_DIR"

  tmp="$INSTALLED_SELF.tmp.$$"
  if [ "$HAVE_LOCAL" = "1" ] && [ -f "${0:-}" ]; then
    # Exactly the code that is running: a local copy needs no second download.
    cp "$0" "$tmp" || die "cannot write $tmp"
  else
    # stdin is already consumed by the interpreter, so the piped case downloads
    # the same URL it came from rather than re-reading a stream that is gone.
    curl -fsSL "$ORIGIN/downloads/freebuff-focus-desktop.sh" -o "$tmp" 2>/dev/null \
      || { rm -f "$tmp"; die "cannot download the tool from $ORIGIN"; }
    got="$(version_of "$tmp")"
    [ -n "$got" ] || { rm -f "$tmp"; die "the download does not look like this tool - nothing was installed"; }
    if [ "$got" != "$VERSION" ]; then
      # A copy older than the code that is running is a stale site, not an
      # update: installing it would hand back a tool missing this very command.
      if version_newer "$VERSION" "$got"; then
        rm -f "$tmp"
        die "the site is serving $got while this run is $VERSION - nothing was installed. Try the one-liner again in a minute."
      fi
      warn "downloaded $got while running $VERSION - installing $got"
    fi
  fi

  chmod 755 "$tmp" 2>/dev/null || true
  mv "$tmp" "$INSTALLED_SELF" || { rm -f "$tmp"; die "cannot install to $INSTALLED_SELF"; }

  write_shim "$COMMAND_NAME" || die "cannot write $BIN_DIR/$COMMAND_NAME"

  ok "installed $INSTALLED_SELF"
  ok "command   $BIN_DIR/$COMMAND_NAME"
  if write_shim "$ALIAS_NAME"; then
    ok "alias     $BIN_DIR/$ALIAS_NAME"
  else
    warn "the $ALIAS_NAME alias was not written - $COMMAND_NAME still works"
  fi

  if path_has_bin; then
    say "  ${DIM}$BIN_DIR is already on PATH${OFF}"
  elif [ "$ADD_PATH" = "1" ]; then
    add_to_path || warn "could not update $(shell_rc) - add $BIN_DIR to PATH yourself"
    say "  Open a new terminal, then run:  $COMMAND_NAME status"
  else
    say ""
    say "  ${B}$BIN_DIR is not on PATH yet.${OFF} Add it for good:"
    say "    echo 'export PATH=\"$BIN_DIR:\$PATH\"' >> $(shell_rc)"
    say "  or rerun setup with --add-path and this is done for you."
  fi

  # A shell that was already open when the launcher was written keeps its own
  # command hash, so the name is there but does not tab-complete until the shell
  # is refreshed. Saying so is cheaper than the confusion it saves.
  say "  ${DIM}If the name does not tab-complete yet: rehash (zsh) or open a new terminal.${OFF}"
}

# Replace the installed copy with whatever the site serves now, keeping the old
# one beside it, then run the new code so the patch is refreshed by the version
# that will be used from now on.
cmd_update() {
  [ -f "$INSTALLED_SELF" ] || die "no installed copy yet - run: curl -fsSL $ORIGIN/downloads/freebuff-focus-desktop.sh | sh"

  say "${B}Freebuff Focus${OFF} - update"
  old="$(version_of "$INSTALLED_SELF")"
  say "  installed  ${old:-unknown}"

  tmp="$INSTALLED_SELF.new.$$"
  curl -fsSL "$ORIGIN/downloads/freebuff-focus-desktop.sh" -o "$tmp" 2>/dev/null \
    || { rm -f "$tmp"; die "cannot reach $ORIGIN - nothing was changed"; }
  new="$(version_of "$tmp")"
  [ -n "$new" ] || { rm -f "$tmp"; die "the download does not look like this tool - kept the installed copy"; }
  say "  available  $new"

  if [ "$new" = "$old" ] && [ "$FORCE" != "1" ]; then
    rm -f "$tmp"
    ok "already up to date"
    return 0
  fi

  if [ "$FORCE" != "1" ] && version_newer "${old:-0}" "$new"; then
    rm -f "$tmp"
    die "the site is serving $new, which is older than the installed ${old:-?} - nothing was changed"
  fi

  cp "$INSTALLED_SELF" "$INSTALLED_SELF.prev" 2>/dev/null || true
  chmod 755 "$tmp" 2>/dev/null || true
  mv "$tmp" "$INSTALLED_SELF" || { rm -f "$tmp"; die "cannot replace $INSTALLED_SELF"; }
  ok "updated    ${old:-unknown} -> $new"
  say "  previous   $INSTALLED_SELF.prev"
  say ""

  # Hand over to the copy that was just installed, with the settings this run was
  # given: the new version does the patching, and --app / --backup-dir / --no-wait
  # survive the handover instead of sending the reader back to the defaults.
  set -- install
  [ -n "$APP" ] && set -- "$@" --app "$APP"
  set -- "$@" --backup-dir "$BACKUP_DIR"
  set -- "$@" --session-dir "$SESSION_DIR"
  case "$RESTART" in
    always) set -- "$@" --restart ;;
    never)  set -- "$@" --no-restart ;;
  esac
  [ "$WAIT" = "1" ] || set -- "$@" --no-wait
  set -- "$@" --timeout "$WAIT_SECS"

  exec sh "$INSTALLED_SELF" "$@"
}

# Remove the command and the installed copy. The patch is left alone on purpose:
# taking away the tool that can undo it must not also take away the undo.
cmd_uninstall() {
  shim="$BIN_DIR/$COMMAND_NAME"
  alias_shim="$BIN_DIR/$ALIAS_NAME"
  removed=0
  if [ -f "$shim" ]; then rm -f "$shim" && { ok "removed $shim"; removed=1; }; fi
  if [ -f "$alias_shim" ]; then rm -f "$alias_shim" && { ok "removed $alias_shim"; removed=1; }; fi
  if [ -f "$INSTALLED_SELF" ]; then
    rm -f "$INSTALLED_SELF" "$INSTALLED_SELF.prev" && { ok "removed $INSTALLED_SELF"; removed=1; }
  fi

  if [ "$removed" = "0" ]; then
    say "  Nothing was installed here."
    return 0
  fi
  say ""
  say "  The patch is still applied. Restore the ads first next time, with a fresh copy:"
  say "    curl -fsSL $ORIGIN/downloads/freebuff-focus-desktop.sh | sh -s revert"
}

cmd_revert() {
  # Nothing may be waiting to write this file once it is being restored.
  stop_watcher
  app="$(find_app)" || die "Freebuff Desktop was not found. Pass --app /path/to/Freebuff.app"
  target="$app/Contents/Resources/orchestrator/orchestrator.js"
  version="$(app_version "$app")"
  backup="$BACKUP_DIR/orchestrator.js.$version.orig"

  if [ ! -f "$backup" ]; then
    if [ -f "$BACKUP_DIR/app.asar.$version.orig" ]; then
      shell_restore "$app" "$version"
      say ""
      say "  Restart Freebuff to bring the window's ads back."
      return 0
    fi
    say "No backup for $version in $BACKUP_DIR"
    if [ -d "$BACKUP_DIR" ]; then
      say "Available backups:"
      for f in "$BACKUP_DIR"/orchestrator.js.*.orig; do
        [ -f "$f" ] && say "  $f"
      done
    fi
    die "nothing to restore"
  fi

  if ! writable "$target"; then
    permission_help
    return 1
  fi

  if ! cp "$backup" "$target" 2>/dev/null; then
    permission_help
    return 1
  fi

  ok "restored $target from $backup"
  shell_restore "$app" "$version"

  if [ "$RESTART" = "never" ]; then
    say "  Quit Freebuff and reopen it to bring the ads back."
    return 0
  fi

  if [ -n "$(orchestrator_pids "$app")" ]; then
    if restart_app "$app"; then
      say "  restarted Freebuff - the ads are back on the next launch."
    elif rescue_app "$app" "$version"; then
      say "  Freebuff is open again."
    else
      warn "could not restart Freebuff - quit it completely (Cmd-Q) and reopen it"
    fi
  else
    say "  Freebuff is not running. The ads come back the next time you start it."
  fi
}

cmd_doctor() {
  say "${B}freebuff-focus-desktop $VERSION${OFF}"
  say "  origin        $ORIGIN"
  say "  os            $(uname -s) $(uname -r)"
  say "  shell         ${SHELL:-unknown}"
  say "  perl          $(command -v perl || echo 'MISSING')"
  say "  codesign      $(command -v codesign || echo '(none)')"
  say "  backup dir    $BACKUP_DIR"
  say "  session dir   $SESSION_DIR"
  say "  commands      $COMMAND_NAME, $ALIAS_NAME (in $BIN_DIR)"

  if app="$(find_app)"; then
    target="$app/Contents/Resources/orchestrator/orchestrator.js"
    say "  app           $app"
    # The app's own version, read from the bundle it would patch - not a constant
    # and not what the tool was built against. The source is named because the
    # label alone used to read as the tool's version.
    say "  freebuff      $(app_version "$app")   (Contents/Info.plist)"
    say "  signature     $(signature_word "$app")"
    say "  orchestrator  $target"
    if [ -f "$target" ]; then
      say "  size          $(wc -c < "$target" | tr -d ' ') bytes"
      writable "$target" && ok "bundle is writable" || bad "bundle is NOT writable (App Management)"
      report="$(engine check "$target" "$DEEP")" || true
      render_report "$report"
    else
      bad "orchestrator.js is missing"
    fi
  else
    bad "Freebuff Desktop was not found"
  fi

  session_line

  if app_running; then warn "Freebuff is running"; else ok "Freebuff is not running"; fi

  # One exit status on every platform, so a wrapper can use this as its preflight
  # check. 1.6 exited 1 on Windows and 0 everywhere else for the same finding,
  # which meant the answer depended on the operating system rather than the app.
  exit 0
}

# Read-only. Prints every candidate site this build contains, so a Freebuff
# release that moved an anchor is a report to read rather than a dead end.
# Nothing inside the bundle is opened for writing.
cmd_scan() {
  app="$(find_app)" || die "Freebuff Desktop was not found in /Applications or ~/Applications.
  Pass --app /path/to/Freebuff.app if it lives somewhere else."
  target="$app/Contents/Resources/orchestrator/orchestrator.js"
  [ -f "$target" ] || die "no orchestrator.js in $app - is that the Freebuff app?"

  version="$(app_version "$app")"

  say "${B}Freebuff Focus${OFF} - anchor scan (tool $VERSION)"
  say "  app      $app"
  say "  freebuff $version (installed)"
  say "  target   $target"
  say ""

  report="$(engine scan "$target" "$DEEP")" || die "the scan could not read $target"

  printf '%s\n' "$report"
  say ""

  out="$BACKUP_DIR/orchestrator-scan.$version.txt"
  if mkdir -p "$BACKUP_DIR" 2>/dev/null && printf '%s\n' "$report" > "$out" 2>/dev/null; then
    ok "saved    $out"
    say "  Nothing inside the app was touched. When a patch reports"
    say "  ${B}not found${OFF}, this file is what re-anchoring the tool needs."
  else
    warn "could not write $out - copy the block above instead"
  fi
}

# What no file can answer: whether the app you are looking at loaded the patched
# file. The orchestrator is read once at launch, so a process that started after
# the patch was written is reading it - and that is the whole test. Waiting is
# the price, because the answer only becomes true after a relaunch.
cmd_verify() {
  app="$(find_app)" || die "Freebuff Desktop was not found in /Applications or ~/Applications.
  Pass --app /path/to/Freebuff.app if it lives somewhere else."
  target="$app/Contents/Resources/orchestrator/orchestrator.js"
  [ -f "$target" ] || die "no orchestrator.js in $app - is that the Freebuff app?"

  version="$(app_version "$app")"
  say "${B}Freebuff Focus${OFF} - desktop tool $VERSION"
  say "  app      $app"
  say "  freebuff $version (installed)"
  say "  target   $target"
  say ""

  report="$(engine check "$target" "$DEEP")" || true

  if [ "$(verdict_of "$report")" != "ok" ]; then
    render_report "$report"
    say ""
    bad "This orchestrator.js does not match what the tool expects."
    say "  There is nothing of this tool's to verify, and nothing was written."
    say ""
    say "  See what this build actually has:  $(cmdname) scan"
    return 1
  fi

  if ! all_applied "$report"; then
    render_report "$report"
    say ""
    say "  ${YELLOW}Not patched yet.${OFF} Run: $(cmdname) install"
    return 1
  fi

  render_report "$report"
  say ""
  verify_running "$app" "$target"
}

# The two times, and the wait between them. Returns 0 only when the process
# running now started after the patch was written.
verify_running() {
  app="$1"; target="$2"
  mtime="$(file_mtime "$target")" || mtime=""
  remaining="$WAIT_SECS"
  announced=0
  waiting=0
  interrupted=0
  trap 'interrupted=1' INT

  while :; do
    pid=""; started=""
    for candidate in $(orchestrator_pids "$app"); do
      s="$(proc_start_epoch "$candidate")" || continue
      if [ -z "$started" ] || [ "$s" -gt "$started" ]; then pid="$candidate"; started="$s"; fi
    done

    # Two seconds of tolerance, and both seconds are the clock's fault: ps
    # reports a process's age in whole seconds, so one started immediately after
    # the write can read as a second before it. No real relaunch is ever that
    # close to the patch, and a false "relaunch and run this again" is worse than
    # a false pass in a window two seconds wide.
    if [ -n "$pid" ] && [ -n "$mtime" ] && [ "$started" -ge "$(( mtime - 2 ))" ]; then
      say "  running    pid $pid, started $(proc_started_at "$pid")"
      say "             $(clock_words "$(( started - mtime ))")"
      ad="$(ad_code_line "$target")"
      if [ -n "$ad" ]; then
        say "  ad code    still in this build: $ad"
      else
        warn "the ad runtime this patch aims at is not in this build"
        say "             Freebuff may have removed it, or moved it. scan lists"
        say "             every site this build does have."
      fi
      say ""
      ok "the running app is the patched file"
      say "  The ad auction in it returns no ads, and the ad client gives up before"
      say "  it sends. What no check here can see is whether an ad break still"
      say "  appears - only you can. On the free tier, run a turn: an ad card is"
      say "  the one carrying an \"AD\" chip or a /track/click link."
      trap - INT
      return 0
    fi

    # Why not, said once, so a long wait does not repeat itself.
    if [ "$announced" = "0" ]; then
      if [ -z "$pid" ]; then
        say "  running    Freebuff is not open."
      elif [ -z "$mtime" ]; then
        say "  running    pid $pid, started $(proc_started_at "$pid")"
        say "             the patch time could not be read, so the two cannot be compared"
      else
        say "  running    pid $pid, started $(proc_started_at "$pid")"
        say "             $(clock_words "$(( started - mtime ))")"
      fi
      announced=1
    fi

    if [ "$WAIT" = "0" ]; then
      say ""
      say "  ${YELLOW}Not verified.${OFF} This check needs Freebuff running the patched"
      say "  file. Quit it completely (Cmd-Q), reopen it, then run it again:"
      say "    $(cmdname) verify"
      trap - INT
      return 1
    fi

    if [ "$waiting" = "0" ]; then
      say ""
      say "  Waiting for Freebuff to be quit and reopened…  ${DIM}(Ctrl-C to stop)${OFF}"
      waiting=1
    fi

    if [ "$interrupted" = "1" ] || [ "$remaining" -le 0 ]; then
      say ""
      say "  ${YELLOW}Stopped waiting.${OFF} The patch itself is fine - this check only"
      say "  needs the relaunch. Run it again once Freebuff is open:"
      say "    $(cmdname) verify"
      trap - INT
      return 1
    fi

    sleep 2
    remaining=$(( remaining - 2 ))
  done
}

# ------------------------------------------------------------------------ run

# Which of the three modes this run asked for. `focus session` is the only
# spelling that is not a duration, so it is checked first and by name.
focus_mode() {
  case "${FOCUS_ARG:-}" in
    '')          printf 'until-unfocus' ;;
    session|SESSION|Session) printf 'session' ;;
    *)           printf 'until' ;;
  esac
}

# install, then record what should end it. The patch is the thing that hides ads;
# the session file only says what will put it back, so a failed install is a
# failed focus and nothing is recorded.
cmd_focus() {
  MODE="$(focus_mode)"
  SECS=""
  if [ "$MODE" = "until" ]; then
    SECS="$(duration_seconds "$FOCUS_ARG")" \
      || die "focus takes a duration like 25m, 90m, 2h or 45s, or the word session"
  fi

  # A second focus replaces the first: one session file, one watcher.
  stop_watcher

  # The watcher re-runs this tool, so a piped run has to leave a copy behind.
  [ "$HAVE_LOCAL" = "1" ] || [ -f "$INSTALLED_SELF" ] || cmd_setup || return 1

  cmd_install || return 1

  mkdir -p "$SESSION_DIR" 2>/dev/null || die "cannot create $SESSION_DIR"
  now="$(date +%s)"
  RUN="$$-$now"
  TARGET="$target"
  BACKUP="$BACKUP_DIR/orchestrator.js.$version.orig"
  STAMP="$(file_stamp "$target")" || STAMP=""
  ENDS=""
  PID=""
  case "$MODE" in
    until)   ENDS=$(( now + SECS )) ;;
    session) PID="$(newest_pid_for "$target")" ;;
  esac

  file="$(session_file)"
  {
    printf 'mode=%s\n' "$MODE"
    printf 'run=%s\n' "$RUN"
    printf 'started=%s\n' "$now"
    printf 'target=%s\n' "$TARGET"
    printf 'backup=%s\n' "$BACKUP"
    printf 'stamp=%s\n' "$STAMP"
    if [ -n "$ENDS" ]; then printf 'endsAt=%s\nduration=%ss\n' "$ENDS" "$SECS"; fi
    if [ -n "$PID" ]; then printf 'pid=%s\n' "$PID"; fi
  } > "$file" 2>/dev/null || die "cannot write $file"

  case "$MODE" in
    until-unfocus) ;;
    *) start_watcher || warn "could not start the watcher - see $SESSION_DIR"; ;;
  esac

  say ""
  case "$MODE" in
    until-unfocus)
      say "${B}Focus is on.${OFF} Ads stay off until you end it:"
      say "    $(cmdname) unfocus"
      say "Nothing else ends this one - closing Freebuff and opening it again"
      say "keeps the quiet, because the patched file is still on disk."
      ;;
    session)
      say "${B}Focus for this session.${OFF} Ads come back when you quit Freebuff:"
      say "    $(cmdname) unfocus     (end it now, without quitting)"
      if [ -n "$PID" ]; then
        say "Watching pid $PID. Quit Freebuff and open it again: the next launch"
        say "reads the original file, so the ads are back with nothing to type."
      else
        say "Freebuff is not open. The watcher starts when it is, and restoring"
        say "the file when it quits."
      fi
      ;;
    *)
      say "${B}Focus until $(clock_at "$ENDS").${OFF} After that the ads come back on"
      say "their own - the original file is restored at the deadline:"
      say "    $(cmdname) unfocus     (end it now)"
      say "A window that is open at the deadline keeps the code it started with,"
      say "so it stays quiet until it restarts."
      ;;
  esac
}

# End the focus now and put the original file back. The session file goes even
# when there was nothing to restore, so a stale session cannot outlive the patch
# it describes - and the revert runs in a subshell, so its exit cannot skip the
# cleanup.
cmd_unfocus() {
  stop_watcher
  status=0
  ( cmd_revert ) || status=$?
  rm -f "$(session_file)" 2>/dev/null || true
  [ "$status" -eq 0 ] || return "$status"
  say "  focus    cleared"
  return 0
}

# Which half of the window stage does this bundle refuse to start with?
#
# The two halves live in one file, so a bundle that dies on launch cannot say
# which one it minds. Rebuilding app.asar four times - pristine, each half, then
# both - and starting each one is the only split this tool can make on a machine
# that has no display: the answer comes from the machine that does.
cmd_diagnose() {
  app="$(find_app)" || die "Freebuff Desktop was not found in /Applications or ~/Applications.
  Pass --app /path/to/Freebuff.app if it lives somewhere else."
  version="$(app_version "$app")"
  asar="$app/Contents/Resources/app.asar"
  plist="$app/Contents/Info.plist"
  backup="$BACKUP_DIR/app.asar.$version.orig"
  plist_backup="$BACKUP_DIR/Info.plist.$version.orig"
  [ -f "$asar" ] || die "no app.asar in $app - this build has no window stage to test"
  app_binary "$app" >/dev/null 2>&1 \
    || die "no executable in $app/Contents/MacOS - this tool cannot start that bundle"
  [ -f "$backup" ] \
    || die "no pristine app.asar.$version.orig in $BACKUP_DIR.
  Run: $(cmdname) install once - it keeps one - then run this again."
  bun="$(shell_bun "$app")" || die "this bundle carries no bun to rewrite app.asar with"
  js="$(shell_js_path)" || die "the patch engine could not be written out"

  say "${B}Freebuff Focus${OFF} - which half of the window stage stops Freebuff"
  say "  app      $app"
  say "  freebuff $version (installed)"
  say ""
  say "  Starts Freebuff four times by hand - unpatched, each half, then both -"
  say "  and puts the pristine file back at the end. Freebuff has to be closed."
  say ""
  quit_app "$app" >/dev/null 2>&1 || true
  stop_watcher

  failed=""
  killed_any=0
  for stage in none request render both; do
    cp "$backup" "$asar" 2>/dev/null || die "could not copy the pristine app.asar back"
    if [ -f "$plist_backup" ]; then cp "$plist_backup" "$plist" 2>/dev/null || true; fi
    patch_err=""
    if [ "$stage" != "none" ]; then
      # The patcher reports what it wrote on stdout, so only a non-zero exit is
      # a failed write.
      patch_out="$(FBD_ONLY="$stage" "$bun" "$js" patch "$asar" 2>&1)" \
        || patch_err="could not write: $patch_out"
      shell_sync_integrity "$app" >/dev/null 2>&1 || true
    fi
    case "$stage" in
      none)    label="Freebuff's own files, nothing written" ;;
      request) label="the ad API block alone" ;;
      render)  label="the ad card hide alone" ;;
      both)    label="both halves, what focus writes" ;;
    esac
    if [ -n "$patch_err" ]; then
      say "  ${YELLOW}skipped${OFF}   $label"
      say "            ${DIM}$(printf '%s\n' "$patch_err" | head -1)${OFF}"
      failed="$failed $stage:write"
      continue
    fi
    if probe_start "$app"; then
      say "  ${GREEN}started${OFF}   $label"
    else
      say "  ${RED}no start${OFF}  $label"
      failed="$failed $stage"
      [ "${PROBE_KILLED:-0}" = "1" ] && killed_any=1
      cp "$(launch_log)" "$SESSION_DIR/diagnose.$stage.log" 2>/dev/null || true
    fi
    quit_app "$app" >/dev/null 2>&1 || true
  done

  # Nothing this tool wrote stays in the bundle: whatever the answer, the reader
  # is left with the app they started with, and it is open.
  cp "$backup" "$asar" 2>/dev/null || true
  if [ -f "$plist_backup" ]; then cp "$plist_backup" "$plist" 2>/dev/null || true; fi
  shell_sync_integrity "$app" >/dev/null 2>&1 || true
  say ""
  say "  ${DIM}app.asar and Info.plist are back to the bytes Freebuff shipped with.${OFF}"

  case "$failed" in
    *none*)
      # The unpatched build not starting is the one answer that has nothing to do
      # with the patch: macOS is refusing the bundle itself.
      if [ "$killed_any" = "1" ]; then
        warn "this Mac kills the copy this tool starts by hand (Killed: 9)"
        say "  Freebuff's own files died the same way, so these four lines say nothing"
        say "  about the patch - and your app opens normally when you start it."
        say "  ${B}Send this output on.${OFF}"
      else
        warn "Freebuff's own files did not start either - the patch is not what stops it"
        say "  macOS is refusing this bundle. That usually means its download flag is"
        say "  still set, and re-downloading it clears that:"
        say "    https://freebuff.com/desktop"
      fi
      ;;
    "")
      ok "every build started here, including the one focus writes"
      say "  So the bundle itself is fine and the stop is elsewhere: the launch this"
      say "  tool does is longer than the one that fails. Send this whole output on."
      ;;
    *request*)
      if [ "$(printf '%s' "$failed" | grep -c render)" = "1" ]; then
        warn "the bundle refuses any rewritten app.asar, not one half of the stage"
        say "  The ad API block and the card hide both stop it, so a live patch"
        say "  cannot work on this build. ${B}Send this output on.${OFF}"
      else
        warn "${B}The ad API block${OFF} is what stops Freebuff from starting"
        say "  The card hide on its own is fine. ${B}Send this output on.${OFF}"
      fi
      ;;
    *render*)
      warn "${B}The ad card hide${OFF} is what stops Freebuff from starting"
      say "  The ad API block on its own is fine. ${B}Send this output on.${OFF}"
      ;;
    *)
      warn "a build this tool wrote did not start"
      ;;
  esac
  say "  Each start's own output is in $SESSION_DIR/diagnose.<stage>.log"
  launch_app "$app" >/dev/null 2>&1 || true
  return 0
}

case "$COMMAND" in
  install)
    # The one-liner is the install path: a piped run with no file behind it puts
    # the command on the machine first, then patches. A local copy just patches.
    [ "$HAVE_LOCAL" = "1" ] || cmd_setup
    cmd_install ;;
  focus)   cmd_focus ;;
  unfocus) cmd_unfocus ;;
  __watch) cmd_watch ;;
  status)  cmd_status ;;
  verify)  cmd_verify ;;
  revert)  cmd_revert ;;
  doctor)   cmd_doctor ;;
  diagnose) cmd_diagnose ;;
  scan)    cmd_scan ;;
  setup)     cmd_setup ;;
  update)    cmd_update ;;
  uninstall) cmd_uninstall ;;
  version) cmd_version ;;
  help)    cmd_help ;;
  *)       die "unknown command: $COMMAND" ;;
esac
